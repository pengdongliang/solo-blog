title: js如何判断当前文本的输入状态——中文输入法的那些坑
date: '2019-06-03 12:00:41'
updated: '2019-06-03 12:00:41'
tags: [JavaScript, 前端]
permalink: /articles/2019/06/03/1573740588046.html
---
> 参考: https://blog.csdn.net/handsomexiaominge/article/details/80977402