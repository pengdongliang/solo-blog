title: react chrome调试工具
date: '2019-06-04 16:44:33'
updated: '2019-06-04 16:44:33'
tags: [React, 前端]
permalink: /articles/2019/06/04/1573740590582.html
---
> 1. 调试组件
<font color=red>React Developer Tools</font>
2. 调试redux
<font color=red>Redux DevTools</font>