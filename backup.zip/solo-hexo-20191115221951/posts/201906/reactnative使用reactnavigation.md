title: react-native使用react-navigation
date: '2019-06-03 11:54:33'
updated: '2019-06-03 11:54:33'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740601963.html
---
## 安装: 
> yarn add react-navigation

 然后安装 `react-native-gesture-handler` ，如过你正在使用 `Expo` ，那么你可以跳过此步骤，因为他包含在SDK中，否则

 > yarn add react-native-gesture-handler
 > react-native link

## <span color="red" data-mce-style="color: red;" style="color: red;">如果报以下错误(**注**: 以下错误是http://localhost:8081/debugger-ui/里查看到的, 如果没有的话, 就是手机一片红报错的)</span>：
1. 
 > error: bundling failed: Error: Unable to resolve module `react-native-gesture-handler` from `D:\react-native\mapDemo\nod
e_modules\@react-navigation\native\src\Scrollables.js`: Module `react-native-gesture-handler` does not exist in the Hast
e module map

 <span color="blue" data-mce-style="color: blue;" style="color: blue;">解决</span>:
 ### `React Native Gesture Handler`是什么？
`React Native Gesture Handler`是`Expo`公司推出的一个库，目的是替代`React Native`自带的 `Gesture Responder System`。

 ### `React Native Gesture Handler`可以带来等多的手势操作和更好的性能，因为它使用了各个平台原生的`touch handling system` 来处理手势
 > yarn add react-native-gesture-handler
 > react-native link react-native-gesture-handler 

2. `DeltaPatcher should receive a base Bundle when being initialized`
 <span color="blue" data-mce-style="color: blue;" style="color: blue;">解决</span>:
 查看pakeage.json里是否安装了`react-navigation-redux-helpers`, 该软件包允许用户从`Redux`中管理其`React Navigation`状态, 如果没有就安装
 > yarn add react-navigation-redux-helpers