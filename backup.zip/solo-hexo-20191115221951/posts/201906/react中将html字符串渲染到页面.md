title: react中将html字符串渲染到页面
date: '2019-06-04 16:40:39'
updated: '2019-06-04 16:40:39'
tags: [React, 前端]
permalink: /articles/2019/06/04/1573740579254.html
---
## 在做`react`项目时，有时候需要将后台传过来的`html`的字符串变成真正的结构渲染到页面，如果直接插入的话页面显示的就是这段字符串，而不会进行`转义`，可以用以下方法插入，便可以html的形式展现：

```
<div dangerouslySetInnerHTML={{__html: "<p>这里是自己要渲染的数据内容</p >"}} />
```