title: vscode识别webpack中alias配置路径(书签)
date: '2019-06-03 11:47:56'
updated: '2019-06-03 11:47:56'
tags: [VsCode, 编辑器]
permalink: /articles/2019/06/03/1573740605721.html
---
> 关于 ctrl+鼠标左键无法识别别名路径的问题
> https://www.cnblogs.com/xiashan17/p/8258267.html

## vscode里面提示: `"type aliases" 只能在 .ts 文件中使用`
解决: 删除它或者禁用vscode插件: `@builtin TypeScript and JavaScript Language Features`