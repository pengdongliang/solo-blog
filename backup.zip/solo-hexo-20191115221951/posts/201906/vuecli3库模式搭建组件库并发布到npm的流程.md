title: vue-cli3库模式搭建组件库并发布到npm的流程
date: '2019-06-04 16:23:53'
updated: '2019-06-04 16:23:53'
tags: [Vue, 前端]
permalink: /articles/2019/06/04/1573740597139.html
---
> 
参考: https://www.jb51.net/article/148692.htm