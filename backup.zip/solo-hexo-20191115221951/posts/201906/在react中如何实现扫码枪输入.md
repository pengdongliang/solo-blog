title: 在react中如何实现扫码枪输入
date: '2019-06-04 16:48:01'
updated: '2019-06-04 16:48:01'
tags: [React, 前端]
permalink: /articles/2019/06/04/1573740585322.html
---
> 参考: https://blog.csdn.net/qq_29311407/article/details/80897514