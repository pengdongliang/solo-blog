title: oneinstack使用
date: '2019-11-10 16:35:46'
updated: '2019-11-10 16:35:46'
tags: [Linux]
permalink: /articles/2019/11/10/1573740591980.html
---
### 默认是做了动静分离（nginx+tomcat），即nginx处理静态资源（jss、ccc、图片等），其余的交给tomcat处理。

### lnmt模式默认（未绑定域名）对应网站根目录/data/wwwroot/default（不是webapps），`部署代码时建议将war包解压（比如example.war，解压命令：jar xf example.war ，注意权限必须为www）`，将其中代码放到对应网站根目录。

- 如果上传代码之后目录结构为:/data/wwwroot/default/WEB-INF，访问地址为：http://IP

- 如果上传代码之后目录结构为:/data/wwwroot/default/example/WEB-INF，访问网站地址为：http://IP/example。


#### **注意：**

- war包也可以不解压即上传到对应网站根目录，但必须注意访问路径和静态资源目录问题。如果访问网站时，静态资源加载不了，可能是原因是做了动静分离静态资源直接有nginx处理，请确认nginx是否能找到相关静态资源（nginx网站根目录:/data/wwwroot/default）

- 如果vhost.sh绑定了域名，如www.example.com，工具会自动生成对应根目录:/data/wwwroot/www.example.com ，请将代码放入此目录。

- Tomcat参数请修改: /usr/local/tomcat/bin/setenv.sh


## **Let's Encrypt**
```
export Ali_Key=LTAI4Fek9DXXUCBfC7SFiFN8 ; export Ali_Secret=WNo4uNXbkoW97CSCWhyMeNHKjRkW94
```

## **强制非*.xx.com/xx.com域名搭建ssl**
```
~/vhost.sh --dnsapi
```

## **添加虚拟主机, 域名如果填入的是泛型域名, 如: *.xx.com/xx.com, 可以出现Let's Encrypt选项**
```
~/oneinstack/vhost.sh
```
  
## **删除虚拟主机**
```
~/oneinstack/vhost.sh --del
```