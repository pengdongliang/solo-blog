title: React Router中IndexRoute组件的用法
date: '2019-06-04 16:46:15'
updated: '2019-06-04 16:46:15'
tags: [React, 前端]
permalink: /articles/2019/06/04/1573740583860.html
---
> 参考: https://blog.csdn.net/sensyup/article/details/77749083