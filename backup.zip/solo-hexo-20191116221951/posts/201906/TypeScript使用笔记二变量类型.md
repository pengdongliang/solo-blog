title: TypeScript使用笔记二(变量类型)
date: '2019-06-04 14:12:35'
updated: '2019-06-04 14:12:35'
tags: [TypeScript, 前端]
permalink: /articles/2019/06/04/1573740597358.html
---
## let和var 
1. var会声明提前, let不会 
2. var可以在一个作用域内重复声明只得到1个, let重复声明会报错 
3. var很怪异, let很正常 

## const 
1. 常量, 不可直接修改, 如果是个object的话可以通过`.`+属性修改 
2. 其它和let一样 ## 解构(es6新特性) 

```
let [a, ...b] = [1, 2, 3, 4] 
console.log(a) // 1 
console.log(b) // [2, 3, 4] 
let [, second, , fourth] = [1, 2, 3, 4] 
console.log(second) // 2 
console.log(fourth) // 4 
let { a: newName1, b: newName2 } = o; // 属性重命名, newName1作为a来访问 
```
## 对象展开还有其它一些意想不到的限制。 首先，它仅包含对象 自身的可枚举属性。 大体上是说当你展开一个对象实例时，你会丢失其方法： 
```
class C { p = 12; m() { } } let c = new C(); let clone = { ...c }; clone.p; // ok clone.m(); // error! 
```