title: WPS
date: '2019-06-03 11:46:36'
updated: '2019-06-03 11:46:36'
tags: [Windows]
permalink: /articles/2019/06/03/1573740598261.html
---
- [WPS Office 2019 专业增强版（11.8.2.8053）](https://www.52pojie.cn/forum.php?mod=viewthread&tid=853635&page=1)

- 把那行xxxx单位的字去了
    `\Program Files (x86)\Kingsoft\WPS Office\11.8.2.8053\oem`
    删除/替换图片就行了