title: expo(react-native框架, 可以用它来比以前更快地构建原生iOS和Android应用程序)
date: '2019-06-03 12:01:47'
updated: '2019-06-03 12:01:47'
tags: [Expo, 前端]
permalink: /articles/2019/06/03/1573740588544.html
---
```
/**
* time: 2019-5-14
* 由于目前expo好多第三方国内的组件几乎没有, 所有暂时不用
* 例如: 
*       1. 地图, expo自带android(google地图), ios(可用自带地图和google地图), 国内手机目前不支持google地图, 而第三方国内地图(高德: Amap 等)目前没有支持expo
*       2. 微信和支付宝也不支持
*       3. ...
*/
```


## 安装expo-cli并运行
- Node.js（版本10或更新版本)
- <span color="blue" data-mce-style="color: blue;" style="color: blue;">[从Play商店下载Android版](https://play.google.com/store/apps/details?id=host.exp.exponent)</span>或<span color="blue" data-mce-style="color: blue;" style="color: blue;">[从App Store 下载iOS版](https://itunes.com/apps/exponent)</span>
``` Bash
$ npm install expo-cli --global
expo init myProject
cd myProject
expo start
```