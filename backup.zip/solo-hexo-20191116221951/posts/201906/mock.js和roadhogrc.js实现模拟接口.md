title: mock.js和roadhogrc.js实现模拟接口
date: '2019-06-03 11:57:16'
updated: '2019-06-03 11:57:16'
tags: [React, Umi, 前端]
permalink: /articles/2019/06/03/1573740588819.html
---
> 参考: https://blog.csdn.net/night_emperor/article/details/82354948