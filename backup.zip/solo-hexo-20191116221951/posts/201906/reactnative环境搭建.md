title: react-native环境搭建
date: '2019-06-03 11:53:54'
updated: '2019-06-03 11:53:54'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740595265.html
---
## Android( [参考: 在Windows下搭建Android开发环境](https://www.jianshu.com/p/7aa85c861624) )

### [安装最新版本的java jdk](https://www.oracle.com/technetwork/java/javase/downloads/index-jsp-138363.html)
> 
配置相关的环境变量：
1. 修改环境变量，新增JAVA_HOME的系统环境变量，值为C:\Program Files (x86)\Java\jdk1.8.0_112，也就是安装JDK的根目录
2. 修改系统环境变量Path，在Path之后新增%JAVA_HOME%\bin;%JAVA_HOME%\jre\bin;
3. 新建系统环境变量CLASSPATH，值为.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar;
4. 保存所有的系统环境变量，同时退出系统环境变量配置窗口，然后运行cmd命令行工具，输入javac，如果能出现javac的命令选项，就表示配置成功！

### 配置安卓环境
> 可以单独安装Android SDK，也可以通过Eclipse ADT或者Android Studio一并安装。推荐使用Android Studio，以下说明会默认以Android Studio的方式说明。请注意选择x86还是x64版本。 

1. 通过[Android Studio](https://developer.android.com/studio/index.html)来安装
安装界面中选择"Custom"选项，确保选中了以下几项
 
- `Android SDK`
- `Android SDK Platform`
- Performance (Intel ® HAXM) ([AMD 处理器看这里](https://android-developers.googleblog.com/2018/07/android-emulator-amd-processor-hyper-v.html))
- `Android Virtual Device`
然后点击"Next"来安装选中的组件。
> 如果选择框是灰的，你也可以先跳过，稍后再来安装这些组件。

 安装 Android SDK
你可以在 Android Studio 的欢迎界面中找到 SDK Manager。点击"Configure"，然后就能看到"SDK Manager"。
`SDK Manager 还可以在 Android Studio 的"Preferences"菜单中找到。具体路径是Appearance & Behavior → System Settings → Android SDK。`
在 SDK Manager 中选择"SDK Platforms"选项卡，然后在右下角勾选"Show Package Details"。展开Android 9 (Pie)选项，确保勾选了下面这些组件（重申你必须使用稳定的翻墙工具，否则可能都看不到这个界面）：
Android SDK Platform 28
Intel x86 Atom_64 System Image（官方模拟器镜像文件，使用非官方模拟器不需要安装此组件）
然后点击"SDK Tools"选项卡，同样勾中右下角的"Show Package Details"。展开"Android SDK Build-Tools"选项，确保选中了 React Native 所必须的28.0.3版本。你可以同时安装多个其他版本。
最后点击"Apply"来下载和安装这些组件。
****
 配置 ANDROID_HOME 环境变量
 React Native 需要通过环境变量来了解你的 Android SDK 装在什么路径，从而正常进行编译。

 打开控制面板 -> 系统和安全 -> 系统 -> 高级系统设置 -> 高级 -> 环境变量 -> 新建，创建一个名为ANDROID_HOME的环境变量（系统或用户变量均可），指向你的 Android SDK 所在的目录（具体的路径可能和下图不一致，请自行确认）：
 SDK 默认是安装在下面的目录：
 > c:\Users\你的用户名\AppData\Local\Android\Sdk
 
 你可以在 Android Studio 的"Preferences"菜单中查看 SDK 的真实路径，具体是Appearance & Behavior → System Settings → Android SDK。

 你需要关闭现有的命令符提示窗口然后重新打开，这样新的环境变量才能生效。
 ****
 把 platform-tools 目录添加到环境变量 Path 中
 打开控制面板 -> 系统和安全 -> 系统 -> 高级系统设置 -> 高级 -> 环境变量，选中Path变量，然后点击编辑。点击新建然后把 platform-tools 目录路径添加进去。

 此目录的默认路径为：
 
 > c:\Users\你的用户名\AppData\Local\Android\Sdk\platform-tools
2. 通过android SDK tools安装(**这个没成功过, 试试下面第三个方法**)
 (1) 下载安装android SDK
 两种方式: 
 1. 官网下载(需翻墙)：https://developer.android.com/studio/index.html 

 2. 无需翻墙下载：http://www.androiddevtools.cn/
 
 3. 参考: [Android SDK Manager和AVD Manager使用（win7_64bit下测试）](https://www.cnblogs.com/kangjianwei101/p/5621238.html)

 ![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdbc1e8f854051db5000000)

 找到SDK Tools，选择下载installer_r24.4.1-windows.exe。

 下载后在需要安装的位置解压，得到：
 
 ![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdbc24bf854051db5000001)
 
 打开SDK Manager.exe，在以下界面中选择：
 
 ![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdbc260f854051db5000002)
 
 然后install
 
 (2) 配置环境变量
 
 右键我的电脑，打开属性，点击高级系统设置，打开环境变量, 选择系统变量：

 1、新建一个环境变量名称为ANDROID_HOME，变量值为当前安装SDK的目录

 SDK位置在例如SDK装在D:\androidSDK中，则环境变量为：
 
 ![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdbc277f854051db5000003)
 
 2、把`%ANDROID_HOME%\tools;%ANDROID_HOME%\build-tools;%ANDROID_HOME%\platform-tools;`添加到Path环境变量文本后面(记得前后面如果没有**;**不要忘记**;**)。或者点新建, 文本依次填入上面`;`号切割出来的
 
 ![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdd013ecac1c546bd000003)
 
 (3) 检测是否安装成功
 
 win+R，输入cmd，打开命令提示符面板。

 1、输入android
 2、输入abd
 3、输入android -h
 
 (4) 安装ADT(可选)
 ADT是Android开发的eclipse插件，用于打包和封装Android应用。抽象数据类型（ADT）是一个实现包括储存数据元素的存储结构以及实现基本操作的算法。在这个数据抽象思想中，数据类型的定 义和它的实现是分开的，这在软件设计中是一个重要的概念。
 
 前提是已经安装好了eclipse以及jdk、并配好了环境

 1、下载ADT.zip

    （1）需翻墙：http://dl-ssl.google.com/android/eclipse/

    （2）无需翻墙：http://www.androiddevtools.cn/

 2、打开eclipse、点击help菜单，选择install new software

      点击Add按钮，点击archive，选择我们所下载的ADT压缩包，然后随便取个名字（例如ADT），确定后就可以看到对应的Developer Tools，全部选中、然后一直next到finish

 3、安装完成后重启eclipse就好了

 `（注：但是最新版的eclipse已经不支持android开发了，需要进行原生android开发，推荐android studio）`
 
3. Android SDK Manager, 下载地址: https://pan.baidu.com/s/1dEEoALN
　顾名思义，Android SDK Manager就是一个Android软件开发工具包管理器，就像一个桥梁，连通本地和服务器，从服务器下载安卓开发所需工具到本地。

　而AVD Manager是一个Android虚拟驱动管理器，主要用来创建安卓模拟器（即手机模拟器）。当然，安卓模拟器所需的镜像（可以理解成模拟器的操作系统）是通过SDK Manager来下载的。

　对于SDK Manager和AVD Manager的使用，还需要一个基础工具包tools提供支持。
　
　下载SDK基础工具包之后，解压，就可以看到如下文件：
　
　![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdcdef9cac1c546bd000000)
　
　将SDK文件夹移动到预设的磁盘下，所在磁盘剩余空间>30G为好。这里建议将SDK文件夹和其他开发工具放到 同一目录如下图，目的是便于查找管理。
　
　![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdcdf10cac1c546bd000001)
　
　1. 启动SDK Manager，可以看到如下图列表：
　 注1：如果不能更新出列表，见注事事项中代理的设置。

　 注2：不同版本的tools，更新出的列表可能有所不同，下图列表以tools25.2.2为依据。
　
　 ![](http://www.p0d0.com:9000/api/file/getImage?fileId=5cdcdf49cac1c546bd000002)
　   
　2. 各工具作用如下：
　 　　　　━━┳Tools目录（**必须的工具**）：

　　　　　　┣ ━━Android SDK Tools（**必须**，只需下载一个版本，一般选最新版本）：基础工具包，版本号带rc字样的是预览版。

　　　　　　┣ ━━Android SDK Platform-tools（**必须**，只需下载一个版本，一般选最新版本）：从android2.3开始划出此目录，存放公用开发工具，比如adb、sqlite3等，被划分到了这里。

　　　　　　┗━━ Android SDK Build-tools（**必须**，可以安装多个版本）：Android项目构建工具。

　　　　━━┳Android xxx（API xx）目录（**可选的各平台开发工具**）：　

　　　　　　┣ ━━Documentation for Android Sdk（**可选**）：安卓开发者官网的一些离线文档，不过下载下来打开也很慢，后面会提供另外一个离线版。

　　　　　　┣ ━━SDK Platform（**必须**）：对应平台的开发工具，需要在哪个版本的平台下开发就下载哪个。

　　　　　　┣ ━━Samples for SDK（**可选**，此项在高版本tools中已不提供，需要在IDE里通过Import Sample引入，当然也可以下载离线版）：内置的安卓示例程序，推荐安装。

　　　　　　┣ ━━Sources for Android SDK（**可选**）：安卓API的源代码，推荐安装。

　　　　　　┗━━ xxxxxxxx  Image（**可选**）：各个以Image结尾的东西是支持相应平台的模拟器，我们就把它想象成一个刷机包吧。（使用真机调试或使用其它模拟器的话不需要安装）

　　　　━━┳Extras目录（可选的扩展）：

　　　　　　┣ ━━Android Support Libraries（**需要**，高版本tools中已不见了，应该是集成到了别的地方）：在低版本平台实现高版本平台控件效果时提供支持。

　　　　　　┣ ━━Android Support Repository（**需要**）：主要是方便在gradle中使用Android Support Libraries，因为Google并没有把这些库发布到maven center或者jcenter去，而是使用了Google自己的maven仓库。

　　　　　　┗━━ Intel x86 Emulator Accelerator(HAXM installer)（**可选**，但非常需要，需要CPU支持虚拟化技术支持）：windows平台的Intel x86模拟器加速工具，配合Intel x86 atom/atom_64 System Image使用可加快模拟器的运行速度。
　
　
　