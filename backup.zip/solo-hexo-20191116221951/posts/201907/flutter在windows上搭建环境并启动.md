title: flutter在windows上搭建环境并启动
date: '2019-07-09 11:56:08'
updated: '2019-07-09 11:56:08'
tags: [flutter, 前端]
permalink: /articles/2019/07/09/1573740582302.html
---
# [**中文官网**](https://flutterchina.club/setup-windows/)
### [**Flutter入门必知小技巧**](https://www.jianshu.com/p/7abf7902316e)

****

## **搭建环境**
 1. 去flutter官网下载其最新可用的安装包，[点击下载](https://flutter.io/sdk-archive/#windows)
 2. 将安装包zip解压到你想安装Flutter SDK的路径（如：C:\src\flutter；注意，不要将flutter安装到需要一些高权限的路径如C:\Program Files\）
 3. 在 `环境变量` -> `用户变量` -> `Path` 里添加`flutter\bin`路径, 如: `E:\flutter\bin`
  使用镜像: 
   1. 添加变量名: `PUB_HOSTED_URL`, 变量值: `https://pub.flutter-io.cn`
   2. 添加变量名: `FLUTTER_STORAGE_BASE_URL`, 变量值: `https://storage.flutter-io.cn`
 4. 打开一个新的命令提示符或PowerShell窗口并运行以下命令以查看是否需要安装任何依赖项来完成安装: `flutter doctor`

****

## **编辑器设置(VSCode)**
 1. 安装Flutter插件, 插件里搜索 `flutter`, 安装, 重启编辑器
 2. 通过Flutter Doctor验证您的设置
 3. 创建新应用
  1. 按 `F1` 打开输入框, 输入 `flutter`, 然后选择 `Flutter: New Project` 点击
  2. 输入 Project 名称 (如myapp), 然后按回车键
  3. 指定放置项目的位置，然后按蓝色的确定按钮
  4. 等待项目创建继续，并显示main.dart文件
 4. 运行应用
  1. 查看 `VS Code` 右下角是否显示 `手机设备`
   1. `真机数据线连接`: 打开安卓手机的usb调试
   2. `模拟器`: 命令: 如夜神模拟器 `adb connect 127.0.0.1:62001`
   3. `真机WIFI连接`:
     前提条件:电脑和手机在同一局域网下
     1. Android:
         1. 使用数据线连接手机和电脑，在ide端能显示移动设备名称
         2. 输入命令行`adb tcpip 5555`
         3. 输入命令行adb connect 你的手机ip地址(例: `adb connect 192.168.1.76:5555`)
         4. 拔掉线，ide端若还能显示设备名称，即OK
     2. iOS
         1. 在XCode项目打开菜单 Window > Devices and Simulators, 然后在打开的菜单中选择 Devices选项.
         2. 使用数据线连接手机和电脑
         3. 在左侧选择连接的设备，然后在右侧勾选[Select Connect via network]复选框.
         4. 当左侧设备出现网状球图标，即可拔掉数据线调试了
  2. 选择 `debugger` 为当前项目, 如没有配置, 请添加新配置, 按 `F5` 启动