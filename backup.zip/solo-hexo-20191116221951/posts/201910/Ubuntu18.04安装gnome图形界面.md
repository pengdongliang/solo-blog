title: Ubuntu18.04安装gnome图形界面
date: '2019-10-25 17:56:39'
updated: '2019-10-25 17:56:39'
tags: [Linux]
permalink: /articles/2019/10/25/1573740592479.html
---
```bash
sudo apt-get update

sudo apt-get upgrade -y
```

安装

我们将使用一种特殊的工具来安装GNOME桌面（因为它通常是一种更安全的路径）。 该工具是任务。 Tasksel是一个特定于Ubuntu和Debian的工具，它有助于将多个相关软件包安装为协调任务。 Tasksel使得安装相关软件包非常容易，这些软件包组成了以下内容：

- LAMP Server
- Mail Server
- Print Server
- Database servers
- Samba file server
- And more


要安装Tasksel，请登录您的服务器并发出命令：
```
sudo apt-get install tasksel -y
# 启动
sudo tasksel
```

将打开一个基于curses的GUI。使用键盘箭头键，向下滚动以选择`Ubuntu desktop`, 按Tab键选择Ok, 重启服务器