title: 轻松打造一款好用的私有云笔记—Leanote 蚂蚁笔记设置指南
date: '2019-10-07 13:39:20'
updated: '2019-10-07 13:39:20'
tags: [Linux]
permalink: /articles/2019/10/07/1573740601005.html
---
## **安装windows**
可以参考这篇文章：
https://post.smzdm.com/p/755474/

## **安装Linux版**
### **1. 安装数据库：下载，安装，启动 MongoDB**
切换到root用户下，然后下载MongoDB
```bash
cd /home

wget https://fastdl.mongodb.org/linux/mongodb-linux-x86_64-3.0.1.tgz

tar -xzvf mongodb-linux-x86_64-3.0.1.tgz
```

创建存储文件夹

```bash
mkdir -p /data/db
```

配置 MongoDB 的环境变量，在 `/etc/profile` 底部添加环境变量:
```bash
vim /etc/profile

echo export PATH=$PATH:/home/mongodb-linux-x86_64-3.0.1/bin >>/etc/profile
```

执如下命令，使环境变量生效
```bash
source /etc/profile
```

启动 MongoDB
```bash
mongod --bind_ip localhost --port 27017 --dbpath /data/db/ --logpath=/var/log/mongod.log --fork
```

### **2. 安装服务器软件**

[下载页面](http://leanote.org/#download)

我们选择下载Linux的64位版2.6.1:
```bash
cd /home

wget https://downloads.sourceforge.net/project/leanote-bin/2.6.1/leanote-linux-amd64-v2.6.1.bin.tar.gz
或者
https://vorboss.dl.sourceforge.net/project/leanote-bin/2.6.1/leanote-linux-amd64-v2.6.1.bin.tar.gz

tar -zxvf leanote-linux-amd64-v2.6.1.bin.tar.gz
```

编辑 Leanote 配置文件 /home/ubuntu/leanote/conf/app.conf

找到 app.secret= 这一项，任意修改一下，比如修改为如下内容：
`app.secret=mynoteXXX`

然后导入leanote的初始化数据：
```bash
mongorestore -h localhost -d leanote --dir /home/ubuntu/leanote/mongodb_backup/leanote_install_data/
```

最后启动 Leanote 服务
```bash
# 后台自动运行
nohup /bin/bash /home/leanote/bin/run.sh >> /var/log/leanote.log 2>&1 &

# 查看nohup后台运行的程序
jobs

# 查看使用某端口的进程
lsof -i:9000  或者  netstat -ap|grep 9000

# 查看到进程id之后，使用netstat命令查看其占用的端口
netstat -nap|grep 进程号

# 停止
kill -9  进程号
```

## **安装客户端**
- 直接去[官网](https://leanote.com/)下载相应的客户端就可以了

### **使用**

登录方式：

- 使用浏览器直接登录：`http://xxx.xxx.xxx.xxx:9000` 即可从网页端访问你的本地云笔记服务。这是的xxx.xxx.xxx.xxx是你安装leanote的IP地址，而端口号9000在没有修改的情况下是默认端口号。
- 使用客户端登录，打开windows客户端，点击下面的登录自建服务

- 分别在第一栏填入：`http://xxx.xxx.xxx.xxx:9000` 这里xxx是你安装服务的机器的ip地址

- 第二栏填入：`admin`

- 第三栏填入：`abc123`   这里用的是默认的用户名和密码，可以根据自己的需要在配置文件里修改


## **备份数据与恢复**
- **注意, 不要在网页翻译成中文的时候操作, 那样按钮点了没反应的**

- 登录网页端后，可以进入管理界面

- 先选择 `mongodb工具配置` 选项来设置备份和恢复的启动程序的绝对路径
```
# mongodump路径
比如: /home/mongodb-linux-x86_64-3.0.1/bin/mongodump

# mongorestore路径
比如: /home/mongodb-linux-x86_64-3.0.1/bin/mongorestore
```

- 选择后台下拉框里的 `后台管理`, 在左边数据(Data)选项里选择`备份与恢复`

- 需要恢复的数据要放入备份文件夹中, 在 `后台管理` 选项里的路径就是. 如下:
```
/home/leanote/bin/src/github.com/leanote/leanote/mongodb_backup/
```

**** 

## **注意**

- 如果服务器内部 `curl localhost:9000` 无法爬取数据的话, 说明没启动成功

- 如果内部能获取数据, 请查看是否未添加端口防火墙

****

## **Docker搭建leanote**
### 访问https://hub.docker.com/, 搜索关键字`leanote`, 以下用的是 `hjh142857/leanote`, 有自动备份.

### 运行leanote
```
docker run -d --name leanote --restart=always -m 512M --cpus=1 -e SITEURL="http://leanote.p0d0.com" -e LANG="zh-cn" -e DAYS="3" -p 9000:9000 -v /usr/local/leanotedata:/data hjh142857/leanote
```

### 说明: https://hub.docker.com/r/hjh142857/leanote