title: React-native安卓调试
date: '2019-06-03 11:53:01'
updated: '2019-06-03 11:53:01'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740585552.html
---
> 
参考: https://www.jianshu.com/p/8db9a3fe0694
参考: [React Native调试技巧与心得](https://www.cnblogs.com/gaosheng-221/p/6954434.html)
参考: [使用模拟器调试react-native步骤（安卓机）](https://www.cnblogs.com/zhangzonghua/p/react-native.html)

安卓模拟器: [Genymotion](http://www.genymotion.net/), 最快的安卓模拟器
测试与模拟APP应用必备

## **Android 真机调试(wifi连接)**
1. 打开震动菜单 (摇动设备)
2. 前往 Dev Settings
3. 选择 Debug server host for devic
4. 输入调试用电脑的局域网IP 后面加上 :8081 才可以正常运行否则还是出错
5. 点击 Reload JS

## **Android 调试注意**
### 
1. 在虚拟机上进行调试可以通过双击R键进行`reload`

2. 调试时只能有且只有一个机器（虚拟机或真机）连接可以使用`adb devices`来查看当前连接设备。
在`Android5.0`以上设备上，将手机通过usb连接到你的电脑，然后通过adb命令行工具运行如下命令来设置端口转发
`adb reverse tcp:8081 tcp:8081`
而且，除了摇晃手机，还可以使用`adb shell input keyevent 82`来调出`Developer Menu`
如果你的终端无法识别adb命令，应在终端或者iTerm界面运行如下命令：
`open ~/.bash_profile`
这样就开了配置文件，然后在zshrc文件里面添加如下配置：
`export ANDROID_HOME=/Users/*****/Library/Android/sdk`（后面配置的是你系统存放SDK的目录）
然后使用下面的命令保存并应用文件
`source ~/.bash_profile`（这个表示默认把系统的配置文件拿过来了）
然后就OK了，小伙伴们可以愉快的玩耍了

3. 有时候`Debug JS Remotely`无法连接，此时可以先检查`Chrome`中打开了几个调试页面，只保留其中一个并检查网址是否是`http://localhost:8081/debugger-ui` ，因为有时候localhost会被替换成ip地址而无法连接，如果还不能连接，保证该网页开启的情况下，再重新跑`react-native run-android/ios`命令

4. 如果你想在`Chrome`的`network`面板看到应用网络信息，可以在`react-native\Libraries\Core\InitializeCore.js` -> 搜索 `XMLHttpRequest`，注释掉 `polyfillGlobal('XMLHttpRequest', () => require('XMLHttpRequest'));`
再在真机或模拟器`reload` 查看Network面板，此时就可以查看到我们的fetch请求了。需要注意的是，当我连接公司内网并需要在请求中加入`token`的时候，注释掉这行代码会导致错误。