title: ant-design-vue组件的三种加载方式
date: '2019-06-03 11:49:56'
updated: '2019-06-03 11:49:56'
tags: [Ant-Design-Vue, Vue, 前端]
permalink: /articles/2019/06/03/1573740592869.html
---
> 
参考: https://my.oschina.net/tongjh/blog/1928824