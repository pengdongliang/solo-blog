title: computed参数
date: '2019-06-04 16:06:31'
updated: '2019-06-04 16:06:31'
tags: [Vue, 前端]
permalink: /articles/2019/06/04/1573740600785.html
---
```
computed: {
    test(vm) {
        return vm; //vm是当前vue实例, computed默认的
    }    
}
```