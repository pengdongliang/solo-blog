title: dva或umi框架使用mockjs模拟数据
date: '2019-06-03 12:00:04'
updated: '2019-06-03 12:00:04'
tags: [Mock, 前端]
permalink: /articles/2019/06/03/1573740578048.html
---
## [官网](http://mockjs.com/examples.html)
## 第一步：在框架下的mock文件夹下新建users.js（对应users路由下的页面）
   
    const Mock = require('mockjs');//导入mock.js模块
    
    const config=require("../src/utils/config");
    const {apiPrefix}=config;
    const userData=Mock.mock({
        'data|95':[{
            'key|+1':1,
            'name':'Edward King',
            'age':32,
            'address':'London, Park Lane no1'
        }]
    })
    
    module.exports={
        //post 请求   /api/v1/users/是拦截地址   方法内部接受request  response对象
        [`GET ${apiPrefix}/users`](req,res){
            res.json(userData)
        }
    }
    
## 第二步：在.roadhogrc.mock.js(dva)或者.umirc.mock.js(umi)中导入mock
    const mock = {}
    require('fs').readdirSync(require('path').join(__dirname + '/mock')).forEach(function(file) {
        Object.assign(mock, require('./mock/' + file))
    })
    module.exports = mock
    
## 第三步：需要数据的地方用axios请求
    import axios from "axios"
    axios.get(`GET ${apiPrefix}/users`, {})
    .then(res=> {
        console.log(res)
    })
    
## <span color="red" data-mce-style="color: red;" style="color: red;">*注意</span>
1. 如果报404错误的话, 检查是否开启了本地代理, 如:
    ```
    "proxy": {
        "/api/v1": {}
    }
    ```
则不能使用`/api/v1`开头的路径