title: idea
date: '2019-06-07 02:35:53'
updated: '2019-06-07 02:35:53'
tags: [Java]
permalink: /articles/2019/06/07/1573740590358.html
---
## idea的下载到 [官网](https://www.jetbrains.com/idea/) 下载即可，其中旗舰版(`UItimate`)拥有更实用功能, jrb 11(`OpenJDK 11`) 比 jrb 8(`OpenJDK 8`) 快

## [idea激活](http://idea.lanyus.com/)
> 复制激活码激活
> 在`hosts`(路径在 `C:\Windows\System32\drivers\etc`) 里添加以下两行:
```
# idea 防止联网

0.0.0.0 account.jetbrains.com

0.0.0.0 www.jetbrains.com
```

## 汉化
1. <s>github上下载对应版本号的汉化包: (**此方法试了没用**)
 > https://github.com/pingfangx/jetbrains-in-chinese/tree/master/IntelliJIDEA
 </s>

2. (`idea版本是: 2019.1.3`, **注: 此包会导致设置打不开**), 在 `thug12` 百度网盘账号下的我的资源里有个 `resources_cn.jar`, 下载下来

3. 将下载下来的 `resources_cn.jar` ，放到软件安装路径下的 `lib` 目录中，重启软件即可

### 如不能打开`设置`和`定位`, 解决:
1. 找到`lib`下的`resources_cn.jar`汉化包, 用解压工具打开, 将其messages文件夹内的
①IdeBundle.properties(系统设置(setting)外观选项加载不出来)
②VcsBundle.properties(系统设置(setting)打不开)
③UIBundle.properties(定位按钮找不到)
三个配置文件删除就可以解决对应问题


## IDEA修改系统缓存目录
> 在IDEA安装目录的bin文件夹中找到idea.properties文件,  将`idea.config.path`, `idea.plugins.path`, `idea.log.path`, `idea.system.path`里面的`${user.home}`改成将要存放目录的位置，我这里修改为`idea.config.path=D:/Program/JetBrains`, 记得删掉前面的 `#` 符号, 重启idea

```
    idea.config.path=E:\Self-Notes\Works\Java\workSpace\config
    idea.system.path=E:\Self-Notes\Works\Java\workSpace\system
    idea.plugins.path=E:\Self-Notes\Works\Java\workSpace\plugins
    idea.log.path=E:\Self-Notes\Works\Java\workSpace\log
```