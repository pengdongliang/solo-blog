title: preflight request(预检请求)
date: '2019-06-04 10:59:08'
updated: '2019-06-04 10:59:08'
tags: [Http, 前端]
permalink: /articles/2019/06/04/1573740591359.html
---
## 有时候我们在调用后台接口的时候，会请求两次, 其实第一次发送的就是preflight request(预检请求)

> 参考: https://www.jianshu.com/p/b55086cbd9af
> 参考: https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS