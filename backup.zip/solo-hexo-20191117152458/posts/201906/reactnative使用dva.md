title: react-native使用dva
date: '2019-06-03 11:54:11'
updated: '2019-06-03 11:54:11'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740598025.html
---
> 
## 参考: [react-native结合dva的使用](https://www.jianshu.com/p/312a8f345735)
## 参考: github [react-native-dva-starter脚手架](https://github.com/nihgwu/react-native-dva-starter)(该目录下src搬过来改一下)
## 参考: [原理](https://www.jianshu.com/p/1af09d80f14c)
## 参考: https://www.jianshu.com/p/312a8f345735

## 安装: 
> yarn add dva-core
> yarn add react-redux




## **注意:**
1. react-navigation-redux-helpers3.0之后有两个变更
 1. `reduxifyNavigator`方法被改名为`createReduxContainer`
 2. `createReactNavigationReduxMiddleware`的参数顺序发生了变化(上下参数调换位置)

2. `react-redux`不推荐使用 `connect` 作为装饰,因为规范是不稳定的。所以不能使用 `@connect()` , 请在导出的时候使用函数调用
 ## **报错:**
1. `Support for the experimental syntax 'decorators-legacy' isn't currently enabled`
 原因: 装饰器写法不被支持
 解决: `bable`转码
 1. `yarn add @babel/plugin-proposal-decorators -D`
 2. 配置`babel.config.js`
 
 ```
    module.exports = {
        presets: ['module:metro-react-native-babel-preset'],
        plugins: [
            ['@babel/plugin-proposal-decorators', { 'legacy': true }]
        ]
    };
 ```