title: vue ui库大全
date: '2019-06-04 16:21:45'
updated: '2019-06-04 16:21:45'
tags: [Vue, 前端]
permalink: /articles/2019/06/04/1573740593447.html
---
- [参考Vue插件总结](https://www.cnblogs.com/calamus/p/8242446.html)
### pc端 
> 
1. [Element](https://github.com/ElemeFE/element)
2. [Vuetify](https://github.com/vuetifyjs/vuetify)
3. [iView](https://github.com/iview/iview)
4. [ant-design-vue](http://okoala.github.io/vue-antd/#!/components)(支持cli3) 

*** 

### H5端 
> 
1. [vux](https://github.com/airyland/vux)(不支持cli3) 
2. [Mint UI](https://mint-ui.github.io/#!/zh-cn)(不支持cli3) 
3. [Vant](https://youzan.github.io/vant/#/zh-CN/popup)(有赞的) 
4. [Onsen UI_移动端](https://onsen.io/v2/api/vue/$ons.modifier.html)
5. [其它的](https://www.cnblogs.com/dupd/p/7735450.html)