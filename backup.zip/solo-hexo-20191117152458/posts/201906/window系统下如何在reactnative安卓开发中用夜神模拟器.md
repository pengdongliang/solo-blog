title: window系统下如何在react native安卓开发中用夜神模拟器
date: '2019-06-03 11:56:09'
updated: '2019-06-03 11:56:09'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740595496.html
---
## 步骤:
> 1. 打开**夜神安卓模拟器**, **[官网](https://www.yeshen.com/)**

> 2. 在 `run-android` 前先执行 `adb connect 127.0.0.1:52001` ,执行此命令是连接到夜神模拟器（端口默认是 `52001` ,如果你的是 `62001` 就改成 `62001` ,根据实际情况来改）

> 3. 执行下 `adb devices` 查看下是否有连接设备，没有的话查看下第二步的 `IP` 和 `端口` 是否正确

> 4. 进入 `react native` 的项目根目录下，执行 `run-android` 。

### `注：当前必须只能有一个机子连着电脑，无论是模拟器还是真机！`

**备注**：如果出现下面这样的错误

![](http://www.p0d0.com:9000/api/file/getImage?fileId=5ce39670e7bc8e724e000000)

- 用模拟器的**摇一摇**功能
- 然后出现下图，点击 `Dev Settings`
- 点击 `Debug server host & port for device` ，设置一下`react native`服务的 `端口` 和 `IP` , 如: `192.168.1.94:8081`
- 最后重启模拟器，再次执行 `react-native run-android`