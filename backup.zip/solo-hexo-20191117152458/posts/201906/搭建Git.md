title: 搭建Git
date: '2019-06-03 11:41:58'
updated: '2019-11-15 18:58:09'
tags: [Linux]
permalink: /articles/2019/06/03/1573740596511.html
---
https://www.cnblogs.com/luozx207/p/9628195.html

## 创建git仓库
> 
cd /home
mkdir git
### 将此文件夹归为git所有
> chown git:git git

**以上创建git仓库只要一次**
****
### 创建一个git仓库
> 
cd git
git init --bare test.git
### 将仓库归为git所有
> chown -R git:git test.git
### 在客户端拉取服务器新建的git仓库
> git clone git@公网ip:/home/gitrepo/test.git
