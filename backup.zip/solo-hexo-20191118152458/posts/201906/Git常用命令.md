title: Git常用命令
date: '2019-06-03 11:38:58'
updated: '2019-11-15 18:57:06'
tags: [Git]
permalink: /articles/2019/06/03/1573740591806.html
---
## 常用命令图示
![](http://leanote.p0d0.com/api/file/getImage?fileId=5dcd51af3629c7001700004a)


****
## 拉取指定分支的代码
```
git clone -b 分支名 仓库地址
```
