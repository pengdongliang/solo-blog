title: Modal使用总结
date: '2019-06-03 11:58:55'
updated: '2019-06-03 11:58:55'
tags: [Ant-Design-React, React, 前端]
permalink: /articles/2019/06/03/1573740578915.html
---
### 高度样式
    
     this.setState({ showInfoDetail: false, protocolInfo: null })}
        footer={[
            ,
        ]}
    >