title: TypeScript使用笔记一(基本类型)
date: '2019-06-04 14:04:30'
updated: '2019-06-04 14:04:30'
tags: [TypeScript, 前端]
permalink: /articles/2019/06/04/1573740596682.html
---
## 布尔类型
```
let isDone: boolean = true // 布尔类型
```

## 数字类型(所有数字都是浮点值, 二, 八, 十, 十六进制文字)
```
let decimal: number = 6; // 十进制(常用) 
let hex: number = 0xf00d; // 十六进制 
let binary: number = 0b1010; // 二进制 
let octal: number = 0o744; // 八进制 
```

## 字符串
```
let isString: string = "hello" // 字符串 
let sentence: string = `hello ${"world"}` // 模板字符串 
```

## 数组
```
let list: number[] = [1, 2, 3] // 数字类型数组 
let list: Array<number> = [1, 2, 3] // 数字类型数组 
let list: [string, number]; list = ["hello", 1] // OK 
list = [1, "hello"] // Error 
```

## 枚举 (首先枚举是单列，而且不可系列化，不可反射的。当属性的内容已经确定，不会经常修改的时候，就可以考虑用枚举，列如性别有男，女就可以用枚举来实现. 从0开始, 后面的值+1, 除非定义了值)
```
enum Sex {man: 0, woman} let woman: Sex = Sex.woman console.log(woman) // 1 
```

## 任何(不知道的变量类型时候, 或者来自动态内容, 不需要类型检查, 任何类型都可以)
```
let all: any = 1 
all = "hello" 
all = {} 
all = [] 
let list: any[] = [1, true, "free"] 
list[1] = 100 
```

## void(函数无返回值)
```
function func(): void { // ... } // 声明变量使用 `void` 没意义, 值只能是"undefined"或者"null" 
let a: void = undefined 
let b: void = null 
```

## 空和未定义
```
let u: undefined = undefined 
let n: null = null 
```

**** 

## never类型(可以是永远不返回的函数的返回值类型, 也可以是变量在类型收窄中不可能为真的类型) - never 是任何类型的子类型, 并且可以赋值给任何类型. - 没有类型是 never 的子类型或者可以复制给 never (除了 never 本身). 
- 在一个没有返回值标注的函数表达式或箭头函数中, 如果函数没有 return 语句, 或者仅有表达式类型为 never 的 return 语句, 并且函数的终止点无法被执行到 (按照控制流分析), 则推导出的函数返回值类型是 never. 
- 在一个明确指定了 never 返回值类型的函数中, 所有 return 语句 (如果有) 表达式的值必须为 never 类型, 且函数不应能执行到终止点. 
由于 never 是所有类型的子类型, 在联合类型中它始终被省略, 并且只要函数有其他返回的类型, 推导出的函数返回值类型中就会忽略它.
一些返回 never 的函数的例子:
```
// 返回 never 的函数必须有无法被执行到的终止点 
function error(message: string): never { throw new Error(message); } // 推断的返回值是 never function fail() { return error("一些东西失败了"); } // 返回 never 的函数必须有无法被执行到的终止点 
function infiniteLoop(): never { while (true) { } } 
```

一些使用返回 never 的函数的例子:
```
// 推断的返回值类型为 
number function move1(direction: "up" | "down") { 
switch (direction) { 
    case "up": return 1; 
    case "down": return -1; 
} 
return error("永远不应该到这里"); } 
// 推断的返回值类型为 number function move2(direction: "up" | "down") { 
    return direction === "up" ? 1 : direction === "down" ? -1 : error("永远不应该到这里"); 
} 
// 推断的返回值类型为 T 
function check<T>(x: T | undefined) { 
    return x || error("未定义的值"); 
} 
因为 never 可以赋值给任何类型, 返回 never 的函数可以在回调需要返回一个具体类型的时候被使用:
function test(cb: () => string) { 
    let s = cb(); 
    return s; 
} 
test(() => "hello"); 
test(() => fail()); 
test(() => { throw new Error(); }) 
```

**** 

## Object(非原始类型, 即非`number`, `string`, `boolean`, `symbol`, `null`, `undefined`)
```
declare function create(o: object | null): void; create({ prop: 0 }); // OK 
create(null); // OK 
create(42); // Error 
```