title: TypeScript使用笔记三(接口)
date: '2019-06-04 14:14:23'
updated: '2019-06-04 14:14:23'
tags: [TypeScript, 前端]
permalink: /articles/2019/06/04/1573740587536.html
---
## 特点
1. 接口好比一个名字, 用来描述一个类或方法里的要求
2. 只要传入的参数有一个满足接口的必要条件的话, 就是被允许的, 参数属性的顺序和检查器检验没关系
例如: 
```
interface LabelledValue {
  label: string;
}

function printLabel(labelledObj: LabelledValue) {
  console.log(labelledObj.label);
}

let myObj = {size: 10, label: "Size 10 Object"};
printLabel(myObj);
```
## 可选属性
1. 接口里的属性不是所有的都是必须的, 如果可选的话, 在属性名后面加个`?`符号
## 只读属性
1. 一些对象属性只能在对象`刚刚创建的时候修改其值`
2. 使用: 在属性名前面用 `readonly` 来指定只读属性
 例如:
 ```
let p1: Point = { x: 10, y: 20 };
console.log(p1.x) // 10
p1.x = 5; // error! 10
 ```

3. TypeScript具有ReadonlyArray<T>类型，它与Array<T>相似，只是把所有可变方法去掉了，因此可以确保数组创建后再也不能被修改：
 ```
let a: number[] = [1, 2, 3, 4];
let ro: ReadonlyArray<number> = a;
ro[0] = 12; // error!
ro.push(5); // error!
ro.length = 100; // error!
a = ro; // error!
 ```

 上面代码的最后一行，可以看到就算把整个ReadonlyArray赋值到一个普通数组也是不可以的。 但是你可以用`类型断言`(可以用来手动指定一个值的类型, 语法: `<类型>值 或者 值 as 类型`, 在 tsx 语法（React 的 jsx 语法的 ts 版）中必须用后一种)重写：
    a = ro as number[];

 **注意** 如果一个对象字面量存在任何“目标类型”不包含的属性时，你会得到一个错误
 例如:
 ```
interface Sq