title: centos7 经常ssh连接不上, 网页打不开, 蚂蚁笔记打不开, ssr连不上, 关闭防火墙
date: '2019-06-03 11:40:42'
updated: '2019-06-03 11:40:42'
tags: [Linux]
permalink: /articles/2019/06/03/1573740586698.html
---
> <span color="red" data-mce-style="color: red;" style="color: red;">仅仅关闭防火墙并不行。应该再开启，再关闭</span>
  开启： `service iptables start`  
  关闭： `service iptables stop`