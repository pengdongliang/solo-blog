title: react-native使用笔记
date: '2019-06-03 11:52:42'
updated: '2019-06-03 11:52:42'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740589655.html
---
## [React-Native 快速入门指南](https://www.zybuluo.com/hopefrontEnd/note/1357037#222-rest%E5%8F%82%E6%95%B0)

## **未找到解决方法的问题: **
- `react-native` 使用 `tsx` 如何支持修饰器(RN0.59暂时发现github上有很多人有这问题, 还未解决)
- `react-devtools` 连接不上 `react-native` 项目
- `react-native fetch` 如何像 `axios` 一样正常请求到接口, 感觉是`headers`那里写法不正确

## 如何删除'警告：已从反应原生核心中提取异步存储...'？
`Async Storage has been extracted from react-native core and will be removed in a future release`
> yarn add @react-native-community/async-storage

链接依赖项
> react-native link @react-native-community/async-storage

然后你像这样导入它，并像以前一样使用它。
> import AsyncStorage from '@react-native-community/async-storage';

## 取消警告
### 您可以使用以下方法来抑制YellowBox警告
> import {YellowBox} from 'react-native';

### 然后在你的渲染方法中，我通常会这样做，App.js因此很容易跟踪我隐藏的那些。
```
render() {
  YellowBox.ignoreWarnings(['Warning: Async Storage has been extracted from react-native core']);  // <- insert the warning text here you wish to hide. 
  return (
    //cool ui stuff
  );
}
```

## `react-native` 在 `Chrome` 上跨域了, 会发送`两次请求`, 分别是`options`和你需要的`method`

1. 关闭chrome浏览器, 鼠标右键浏览器选择`属性`->`快捷方式`->`目标`文本最后面添加 ` --disable-web-security --user-data-dir`, 注意 ` --disable` 前面有空格.
2. **注意不要把 `chrome` 固定在任务栏里**, 放在桌面点击打开, 就不会跨域了