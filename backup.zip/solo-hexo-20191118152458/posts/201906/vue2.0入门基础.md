title: vue2.0入门基础
date: '2019-06-04 16:18:26'
updated: '2019-06-04 16:18:26'
tags: [Vue, 前端]
permalink: /articles/2019/06/04/1573740602414.html
---
> 参考: [Vue.js 2.0 快速上手精华梳理](https://blog.csdn.net/sinat_17775997/article/details/77824878)

*** 
> 参考: [rem用vue做项目的一些总结](https://yq.aliyun.com/articles/610273)

*** 
> 参考: [Vue项目使用vw实现移动端适配教程](https://www.jianshu.com/p/eb0d00e8ffed)
参考: [vue-cli3.0项目中使用vw——相比flexible更原生的移动端解决方案](https://blog.csdn.net/qq_31393401/article/details/82354879)
参考: [Vue.js 移动端适配之 vw 解决方案](https://segmentfault.com/a/1190000016247061)

*** 
> 参考: [Vue+ts下的移动端vw适配（第三方库css问题）](https://zhuanlan.zhihu.com/p/36913200)

*** 
> - 组件懒加载 `$ npm i @xunlei/vue-lazy-component` 

*** 
> - [手把手，从无到有带你用vue进行项目实战 系列一(搭建框架篇)](https://blog.csdn.net/franktaoge/article/details/80264425)

*** 
> - [Apache，Nginx部署vue项目](https://blog.csdn.net/bocongbo/article/details/83957206)

***