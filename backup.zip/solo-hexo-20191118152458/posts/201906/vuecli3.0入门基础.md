title: vue-cli3.0入门基础
date: '2019-06-04 16:07:55'
updated: '2019-06-04 16:07:55'
tags: [Vue, 前端]
permalink: /articles/2019/06/04/1573740582842.html
---
### vue-cli3.0 特性解读 
> https://www.jb51.net/article/138703.htm 

***

### 支持vue-cli3.0的运营后台ui库 
> 
[vuetify](https://vuetifyjs.com/zh-Hans/components/api-explorer)
[ant-design-vue](https://vue.ant.design/components/layout-cn/)

**** 
### Vue后台常用模板 
> 
- vue-xuAdmin权限管理后台模板(vue + element-ui) 
github：https://github.com/Nirongxu/vue-xuAdmin
[预览地址](https://nirongxu.github.io/vue-xuAdmin/dist/#/index)
- vue + element 
在线地址：http://blog.gdfengshuo.com/example/work/#/dashboard
文档: http://element-cn.eleme.io/#/zh-CN/component/installation
- Vue Admin 
官网：https://admin.vuebulma.com
地址：https://github.com/taylorchen709/vue-admin 
- vue-manage-system 
地址：https://github.com/lin-xin/vue-manage-system 

*** 

- [关于 Vue cli 3的配置 vue.config.js 和使用](https://blog.csdn.net/u012302552/article/details/81742907)

*** 
- [vue-cli 3.x脚手架配置并使用vux](https://blog.csdn.net/Honnyee/article/details/82181620)

*** 
- [[全网最全的 Vue CLI 3 原创合集] 你要的这里都有](https://segmentfault.com/a/1190000016414755) 

*** - [vue-cli3.0如何使用CDN区分开发、生产、预发布环境](https://www.jb51.net/article/151222.htm)

*** 
- [全局安装 Vue cli3 和 继续使用 Vue-cli2.x](https://blog.csdn.net/u012302552/article/details/81703202)