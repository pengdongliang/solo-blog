title: 云服务器进行ssh时，一段时间不操作就自动断开连接的解决方法
date: '2019-06-03 11:41:03'
updated: '2019-06-03 11:41:03'
tags: [Linux]
permalink: /articles/2019/06/03/1573740591638.html
---
vim /etc/ssh/sshd_config

- 找到以下两项配置
```
    #ClientAliveInterval 0
    #ClientAliveCountMax 3
    #LoginGraceTime 2m
    #TCPKeepAlive yes
```
- 修改为
```
    # 指定了服务器端向客户端请求消息 的时间间隔, 默认是0, 不发送.
    ClientAliveInterval 60
    # 使用默认值3即可.ClientAliveCountMax表示服务器发出请求后客户端没有响应的次数达到一定值, 就自动断开，正常情况下, 客户端不会不响应.
    ClientAliveCountMax 3
    # 表示在用户用ssh登陆,但是没有输入密码时,多少秒后自动断链
    LoginGraceTime 0
    # 保持连接
    TCPKeepAlive yes
```
1. 客户端每隔多少秒向服务发送一个心跳数据
2. 客户端多少秒没有相应，服务器自动断掉连接
3. 重启sshd服务(centos7+)
```
$ systemctl restart sshd
```