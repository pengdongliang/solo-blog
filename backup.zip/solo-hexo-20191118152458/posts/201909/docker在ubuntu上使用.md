title: docker在ubuntu上使用
date: '2019-09-28 15:30:11'
updated: '2019-09-28 15:30:11'
tags: [Java]
permalink: /articles/2019/09/28/1573740602879.html
---
## **安装docker**
### 1.通过包管理器安装
```
#由于apt官方库里的docker版本可能比较旧，所以先卸载可能存在的旧版本
sudo apt-get remove docker docker-engine docker-ce docker.io
#更新apt包索引
sudo apt-get update
#安装以下包以使apt可以通过HTTPS使用存储库（repository）
sudo apt-get install apt-transport-https ca-certificates curl software-properties-common
#添加Docker的官方GPG密钥
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
#安装stable存储库
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
#再更新一下apt包索引
sudo apt-get update
#安装最新版本的Docker CE
sudo apt-get install docker-ce
#这里安装的最新版，其实是安装你电脑上可用的最新版，查看系统可用的版本
apt-cache madison docker-ce
#选择要安装的特定版本，第二列是版本字符串，第三列是存储库名称，它指示包来自哪个存储库，以及扩展它的稳定性级别。
#要安装一个特定的版本，将版本字符串附加到包名中，并通过等号(=)分隔它们
sudo apt-get install docker-ce=<VERSION>
```

### 2.使用便捷脚本安装
```
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

## **Ubuntu使用非root用户运行docker**
```
sudo groupadd docker #一般自动创建了
sudo usermod -aG docker userName #userName是用户名
sudo systemctl restart docker
# 关闭当前ssh重新连接即可
```

## **查看容器所有信息**
```
docker inspect 容器名称
```

## **查看容器IP**
```
docker inspect --format='{{.NetworkSettings.IPAddress}}' 容器ID/容器名称
```

## **查看容器运行状态**
```
docker inspect --format '{{.Name}} {{.State.Running}}' 容器名称
```

## **docker里的mongo备份数据并导出真机**
```
docker exec -it mymongo /bin/bash

# 在容器内部，导出数据到容器内部的指定文件夹
# mongodump -h 127.0.0.1 --port 端口 -d 库名 -o docker虚拟目录
mongodump -h 127.0.0.1 --port 27017 -d leanote -o /leanote_back

# 退出docker mongodb容器
exit

# docker cp <mongodb容器名>:/test/mongodBack/
docker cp <mongodb容器名>:/test/mongodBack/ /home/opt/mongodbData/(此为真机目录)
```
bin/src/github.com/leanote/leanote/mongodb_backup/

## **docker里的mongo导入数据**
```
# 将宿主机上的mongo数据文件夹复制到docker里面的prod_data文件夹下去, 2af787c52ac4用docker ps获得容器ID
docker cp /home/ubuntu/backup_leanote_20191029 2af787c52ac4:/prod_data/

# 进入docker命令模式 
docker exec -it mongodb /bin/bash

# mongorestore -d dbname --username xxx --password xxx prod_data
# 如不需要用户密码可省略:
mongorestore -d leanote prod_data
```


****

## **启动dubbo后台管理**
### **必须先在dubbo-admin-ui根目录下面运行 `npm run build` 生成dist文件**
mvn clean package
mvn --projects dubbo-admin-server spring-boot:run

## **安装maven**
```
wget http://repos.fedorapeople.org/repos/dchen/apache-maven/epel-apache-maven.repo -O /etc/yum.repos.d/epel-apache-maven.repo

yum -y install apache-maven

# 配置环境变量
vi /etc/profile

# 将下面代码拷贝到文件末尾并保存
# java
export JAVA_HOME=/usr/local/jdk8
export JRE_HOME=${JAVA_HOME}/jre
export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib
export PATH=.:${JAVA_HOME}/bin:$PATH

# maven
export MVN_HOME=/usr/share/maven
export PATH=${MVN_HOME}/bin:$PATH
```


## **使用zookeeper**
```
# 拉取zookeeper镜像
docker pull zookeeper:3.5

# 创建容器
docker create --name zk -p 2181:2181 zookeeper:3.5

# 运行
docker start zk

# 查看运行
docker ps
```

## **使用percona(mysql)**
```
# 拉取percona镜像
docker pull percona:5.7.23

# 创建容器, 挂载文件, 并运行
docker run -d -p 3306:3306 --privileged=true -v /data/mysql-data:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=root --name percona percona:5.7.23

# 参数说明:
--name: 指定容器名称
-v: /data/mysql-data:/var/lib/mysql  讲主机目录/data/mysql-data挂载到容器的/var/lib/mysql上
-p:  3306:3306 设置端口映射, 主机端口是3306, 容器内部端口是3306
-e:  MYSQL_ROOT_PASSWORD=root 设置root用户的密码为root
percona:5.7.23  镜像名:版本

# 查看运行
docker ps
```
[虚拟机中docker安装mysql远程无法访问解决方法](https://blog.51cto.com/autophp/2319467)

****

## **ubuntu中Docker使用percona(mysql)文件挂载，容器中没有执行权限**
### 解决: 
```
#开启目录权限(挂载目录开启权限)
chmod a+rwx /data/mysql-data/ 

#开启docker挂载权限
chmod a+rw /var/run/docker.sock 
```

## **Docker使用redis集群**
```
docker pull redis:5.0.2

# 创建容器
# 参数说明: 
# --cluster-enabled 是否开启集群  --cluster-config-file 集群配置文件
# --net 制定docker网络类型, host为何主机共享ip:port
docker create --name redis-node01 --net host -v /data/redis-data/node01:/data redis:5.0.2 --cluster-enabled yes --cluster-config-file nodes-node-01.conf --port 6379

docker create --name redis-node02 --net host -v /data/redis-data/node02:/data redis:5.0.2 --cluster-enabled yes --cluster-config-file nodes-node-02.conf --port 6380

docker create --name redis-node03 --net host -v /data/redis-data/node03:/data redis:5.0.2 --cluster-enabled yes --cluster-config-file nodes-node-03.conf --port 6381

docker start redis-node01 redis-node02 redis-node03

# 无法杀掉redis进程
# 原因: 
# 在Linux上，如果开了redis的守护进程，kill -9和redis-cli shutdown 命令是无法杀掉 redis 进程的 ，杀掉就会重新启动一个新的进程
# 解决:
# /etc/init.d/redis-server stop

# 开启集群
docker exec -it redis-node01 /bin/bash

# 172.17.0.1是docker0开启的ip, 如果不行的话使用 docker inspect redis-node01 查看IP替换
# 此方法不能被外部使用: redis-cli --cluster create 172.17.0.4:6379 172.17.0.5:6380 172.17.0.6:6381 --cluster-replicas 0
# 这个主机:
# redis-cli --cluster create 182.61.190.153:6379 182.61.190.153:6380 182.61.190.153:6381 --cluster-replicas 0

# 192.168.32.128是主机的ip地址(推荐这样使用, 不过有安全隐患)
redis-cli --cluster create 192.168.32.128:6379 192.168.32.128:6380 192.168.32.128:6381 --cluster-replicas 0

# 开启集群的时候报错: Either the node already knows other nodes (check with CLUSTER NODES) or contains some key in database 0
# 解决: rm -rf /data/redis-data/

# centos7开启集群的时候报错: Could not connect to Redis No route to host
# 解决: iptables -F

# 关闭redis集群(待测试, docker关闭是否输入正常关闭)
redis-cli -p 6379 6380 6381 shutdown
```

## **docker创建mongo**

```
docker pull mongo:4.0.3

# 创建mongo容器, 并映射
docker create --name mongodb -p 27017:27017 -v /data/mongodb:/data/db mongo:4.0.3

# 进入mongo
docker exec -it mongodb /bin/bash

```

## **docker安装rocketmq**

```
# 此镜像包为第三方的
docker pull foxiswho/rocketmq:server-4.3.2
docker pull foxiswho/rocketmq:broker-4.3.2

#创建nameserver容器
docker create -p 9876:9876 --name rmqserver \
-e "JAVA_OPT_EXT=-server -Xms128m -Xmx128m -Xmn128m" \
-e "JAVA_OPTS=-Duser.home=/opt" \
-v /data/rmq/rmqserver/logs:/opt/logs \
-v /data/rmq/rmqserver/store:/opt/store \
foxiswho/rocketmq:server-4.3.2

#创建broker容器
docker create -p 10911:10911 -p 10909:10909 --name rmqbroker \
-e "JAVA_OPTS=-Duser.home=/opt" \
-e "JAVA_OPT_EXT=-server -Xms128m -Xmx128m -Xmn128m" \
-v /data/rmq/rmqbroker/conf/broker.conf:/etc/rocketmq/broker.conf \
-v /data/rmq/rmqbroker/logs:/opt/logs \
-v /data/rmq/rmqbroker/store:/opt/store \
foxiswho/rocketmq:broker-4.3.2

#启动容器
docker start rmqserver rmqbroker

#停止删除容器
docker stop rmqbroker rmqserver
docker rm rmqbroker rmqserver
```

## 部署RocketMQ的管理工具

RocketMQ提供了UI管理工具，名为rocketmq-console，项目地址：https://github.com/apache/rocketmq-exter
nals/tree/master/rocketmq-console
该工具支持docker以及非docker安装，这里我们选择使用docker安装

```
#拉取镜像
docker pull styletang/rocketmq-console-ng:1.0.0

#创建并启动容器
docker run -e "JAVA_OPTS=-Drocketmq.namesrv.addr=192.168.32.128:9876 -Dcom.rocketmq.sendMessageWithVIPChannel=false" -p 8082:8080 -t styletang/rocketmq-console-ng:1.0.0

```

通过浏览器进行访问：http://192.168.32.128:8082/#/

## **docker容器内部相互访问**
如: 一个容器需要访问docker里的mysql
### 在mysql容器创建时可以加上`--network=host`
> 参考: https://blog.csdn.net/subfate/article/details/81396532