title: docker搭建solo博客
date: '2019-11-14 16:45:47'
updated: '2019-11-15 18:38:36'
tags: [Linux]
permalink: /articles/2019/11/14/1573740605333.html
---
## **1.安装 MySQL**
****
### 这里选择5.6
```
# 安装mysql:5.6,直接docker run 他会自动去官方镜想下载
# MYSQL_ROOT_PASSWORD=你的数据库密码
docker run --name mysql --restart=always --network=host -v /usr/local/mysql-data:/var/lib/mysql -p 3306:3306 -e  MYSQL_ROOT_PASSWORD=xxxxxx -d mysql:5.6

# docker安装的mysql默认允许远程连接，可以使用Navicat等软件连接数据库
# 进入容器mysql
docker exec -it mysql bash

# 进入数据库 p后面跟你的密码
mysql -uroot -pXXX

# 创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci)
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
# 出现Query OK, 1 row affected (0.00 sec)表示成功
#退出数据库
exit
#退出容器
exit
```

## **2.安装 solo**
****
### 直接运行以下命令

```
# 注意: 如果不挂载皮肤，请勿加皮肤挂载的参数。
# 如果使用了`-v /usr/local/solo-blog/skins:/opt/solo/skins/`, 在`/usr/local/solo-blog/skins/下使用`git clone https://github.com/b3log/solo-skins.git`下载皮肤放进去

docker run --detach --name solo --network=host \
--env RUNTIME_DB="MYSQL" \
--env JDBC_USERNAME="xxx" \
--env JDBC_PASSWORD="xxxxxx" \
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
-d \
--restart=always \
-v /usr/local/solo-blog/log4j.properties:/opt/solo/WEB-INF/classes/log4j.properties \
-v /usr/local/solo-blog/skins:/opt/solo/skins/ \
-v /usr/local/solo-blog/images:/opt/solo/images/ \
-v /usr/local/solo-blog/markdowns:/opt/solo/markdowns/ \
b3log/solo --listen_port=9999 --server_scheme=https --server_host=www.p0d0.com --server_port=
```
### 上面的命令参数说明

- `--env JDBC_PASSWORD="123456"` 将 123456 换成你的密码
- `--listen_port=8080` 监听的端口
- `--server_scheme=http` 请求方式，暂时使用 http，后面我们会换成 https
- `--server_host=www.jinjianh.com` 你的域名，如果你没有域名可以写 ip 地址
- `--rm`因为这个容器后面要删掉，带上 rm 会省很多事。

### **注意**
- 如遇到mysql无法连接提示拒绝访问: 删除之前挂载的目录
- 如遇到solo无法启动, 查看mysql容器创建的时候是否配置了容器之间相互访问, 如: 加上 `--network=host`
