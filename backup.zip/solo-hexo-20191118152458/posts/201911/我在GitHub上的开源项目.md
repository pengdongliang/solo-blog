title: 我在 GitHub 上的开源项目
date: '2019-11-16 22:09:50'
updated: '2019-11-16 22:09:50'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [tabs-touch](https://github.com/pengdongliang/tabs-touch) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/pengdongliang/tabs-touch/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/pengdongliang/tabs-touch/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/pengdongliang/tabs-touch/network/members "分叉数")</span>

基于 Vue 的滑动切换页面和tab(可容纳多个页面,每个页面内容多了滑动卡的话可懒加载每一页内容)



---

### 2. [solo-blog](https://github.com/pengdongliang/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pengdongliang/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pengdongliang/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pengdongliang/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.p0d0.com`](https://www.p0d0.com "项目主页")</span>

pdl 的个人博客 - 记录精彩的程序人生



---

### 3. [react-vertical-timeline-component-fix](https://github.com/pengdongliang/react-vertical-timeline-component-fix) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/pengdongliang/react-vertical-timeline-component-fix/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/pengdongliang/react-vertical-timeline-component-fix/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/pengdongliang/react-vertical-timeline-component-fix/network/members "分叉数")</span>

修复编译失败提示: 

