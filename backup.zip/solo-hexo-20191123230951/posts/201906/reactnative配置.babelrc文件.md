title: react-native 配置 .babelrc 文件
date: '2019-06-06 00:08:26'
updated: '2019-06-06 00:08:26'
tags: [React-Native, 前端]
permalink: /articles/2019/06/06/1573740583073.html
---
## 模板解析(路径别名) 插件: `babel-plugin-module-resolver`
```
{
    "presets": ["module:metro-react-native-babel-preset"], // 这里必须加上
    "plugins": [
        [
            "module-resolver",
            {
                "root": [
                    "./"
                ],
                "alias": {// 别名
                    "^@(.+)": "./src/\\1" // 匹配所有以@开头的路径名
                },
                "extensions": [".js", ".ios.js", ".android.js"] // react-native 需要这个
            }
        ]
    ]
}
```