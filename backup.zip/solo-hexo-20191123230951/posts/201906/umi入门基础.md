title: umi入门基础
date: '2019-06-03 11:57:28'
updated: '2019-06-03 11:57:28'
tags: [React, Umi, 前端]
permalink: /articles/2019/06/03/1573740595724.html
---
> ### umi路由
> https://umijs.org/zh/guide/router.html#_404-%E8%B7%AF%E7%94%B1

***
> ### umi路由
> https://umijs.org/zh/guide/router.html#_404-%E8%B7%AF%E7%94%B1
> https://blog.csdn.net/eunice_sytin/article/details/83584609

***

> ### Umi入门.语雀
> https://www.yuque.com/umijs/umi

***
> ### UmiJS介绍--webpack配置（七）
> https://blog.csdn.net/eunice_sytin/article/details/83587697

***
> ### Umi分包加载配置
> https://blog.csdn.net/weixin_33768153/article/details/84346865