title: 轨迹展示-海量数据-高德地图API
date: '2019-06-03 11:52:21'
updated: '2019-06-03 11:52:21'
tags: [前端, 插件]
permalink: /articles/2019/06/03/1573740606596.html
---
> 参考: https://lbs.amap.com/api/javascript-api/reference-amap-ui/mass-data/pathsimplifier