title: flutter常用插件大全
date: '2019-07-15 15:36:18'
updated: '2019-07-15 15:36:18'
tags: [flutter, 前端]
permalink: /articles/2019/07/15/1573740586006.html
---
## 状态管理
> `fish-redux` (阿里咸鱼, **推荐使用**)
> `bloc`
> `fish-redux-template` (支持编辑器插件分别有vscode 和Android studio)