title: Flutter在AndroidStudio上使用帮助
date: '2019-08-05 10:52:25'
updated: '2019-08-05 10:52:25'
tags: [flutter, 前端]
permalink: /articles/2019/08/05/1573740607510.html
---
## 点击 open android module in Android Studio 报错: `Exception: Cannot run program "E:\android-studio": CreateProcess error=5, 拒绝访问。`
### 解决: 
1. 重启 Anroid Studio, 就行了

## **报错: `couldn't find "libflutter.so`**
### 解决, 在app下的build.gradle里面添加如下代码:
```
android { 
  defaultConfig { 
     .... 
     .... 
     ndk { 
        abiFilters'armeabi-v7a' 
     }
   }
  .... 
  .... 
  .... 
}
```