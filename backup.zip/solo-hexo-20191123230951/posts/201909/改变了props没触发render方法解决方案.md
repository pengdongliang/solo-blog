title: 改变了props没触发render方法解决方案
date: '2019-09-17 13:44:02'
updated: '2019-09-17 13:44:02'
tags: [React, 前端]
permalink: /articles/2019/09/17/1573740598919.html
---
## 原因: 如果复制一个很复杂的对象给 `state` 或者 `props` 后, 由于 `js未深拷贝` 导致的
解决:
1. 触发了 state 或者 props 后, 手动调用 `this.forceUpdate()` 方法来强制更新渲染
2. 深拷贝数据, 再赋值更新 state 或者 props, 可以使用如下示例代码:
```
import _ from "lodash"

let newData = _.cloneDeep(复杂数据)
this.props.dispatch({
    type: "",
    payload: {data: newData}
})
```