title: Carousel走马灯,轮播图(antd V2.12.1添加左右切换按钮和跳转到指定位置)
date: '2019-06-03 11:58:41'
updated: '2019-06-03 11:58:41'
tags: [Ant-Design-React, React, 前端]
permalink: /articles/2019/06/03/1573740588270.html
---
### antd最新版可以使用next(), prev(), goTo()
### antd旧版使用refs.slick.slickNext(), refs.slick.slickPrev(), refs.slick.slickGoTo()
    next = ()=> {
        this.carouselRef.refs.slick.slickNext();
    }
    prev = ()=> {
        console.log(this.carouselRef)
        this.carouselRef.refs.slick.slickPrev();
    }
    render() {<div>
            {/** `注意` 这里onClick里的方法需放到外部使用, 不能直接在里面写this.carouselRef.refs.slick.slickPrev(), 因为这样获取不到this.carouselRef*/}
            
             (this.carouselRef = el)}
            >
            {
                fileList.map(item => {
                    return <img src="{item.url}" alt="" data-mce-src="file:///E:/leanote-2.6.1/resources/app/{item.url}">
                })
            }
            
            {/** `注意` 这里onClick里的方法需放到外部使用, 不能直接在里面写this.carouselRef.refs.slick.slickNext(), 因为这样获取不到this.carouselRef*/}
            
        </div>
    }