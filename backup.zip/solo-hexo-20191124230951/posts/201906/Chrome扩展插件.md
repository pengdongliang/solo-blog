title: Chrome扩展插件
date: '2019-06-03 11:24:41'
updated: '2019-06-03 11:24:41'
tags: [Chrome]
permalink: /articles/2019/06/03/1573740589883.html
---
## 免费广告拦截程序
> Adblock Plus

## 可以打开本地Axure生成的原型
> Axure RP Extension for Chrome

## React(两件套)
> React Developer Tools  +  Redux DevTools

## Vue
> Vue.js devtools

## WEB前端助手
> FeHelper

## 滑词翻译
> 有道词典Chrome划词插件