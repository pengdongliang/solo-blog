title: react ui库大全
date: '2019-06-04 16:43:35'
updated: '2019-06-04 16:43:35'
tags: [React, 前端]
permalink: /articles/2019/06/04/1573740596916.html
---
### pc端-ui库
> 
1. <font color=red>Ant Design of React</font>
    文档: https://ant.design/docs/react/introduce-cn

***
### H5端-ui库
> 
1. <font color=red>Ant Design Mobile of React</font>
    预览: https://mobile.ant.design/kitchen-sink/
    文档: https://mobile.ant.design/docs/react/introduce-cn
    (这个里面有滑动切换tab)
2. <font color=red>bee-mobile</font>
    预览: https://bee-mobiles.github.io/#/components/overview
    文档: https://bee-mobiles.github.io/#/docs/getting-started
    (这个没有滑动切换tab, 但是其它组件特效很好看)

***