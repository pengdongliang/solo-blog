title: vscode 前端插件推荐(书签)
date: '2019-06-03 11:47:43'
updated: '2019-06-03 11:47:43'
tags: [VsCode, 编辑器]
permalink: /articles/2019/06/03/1573740592151.html
---
> https://segmentfault.com/a/1190000011779959 

****
> 代码静态类型检查插件:  Flow Language Support

## 方法代码块的注释生成方法
> 插件: Document This
> 使用: 将光标放置于function上面, 快捷键是`Ctrl+Alt+D`加`Ctrl+Alt+D`

## 在文件头部添加注释文本信息
> 插件: vscode-fileheader
> 使用: 在光标处快捷键是`Ctrl+Alt+I`

## react项目快速生成代码块
> 插件: ES7 React/Redux/GraphQL/React-Native snippets
> 使用: 输入`rcc`是简版类组件包含render, 输入`rcfc`是完整的类

## 添加文件头部注释和函数注释(相当于两个功能集中在一个插件里)
> 插件: koroFileHeader
>> 使用: 
>>> 1. 文件头部添加注释, 快捷键：window：ctrl+alt+i,mac：ctrl+cmd+i
2. 在光标处添加函数注释, 快捷键：window：ctrl+alt+t,mac：ctrl+cmd+t
3. 快捷键不能使用请查看首选项快捷键里是否被占用了

## git增强版
> 插件: GitLens 
> 功能: 可以自动在光标处文件显示提交信息, and 其它