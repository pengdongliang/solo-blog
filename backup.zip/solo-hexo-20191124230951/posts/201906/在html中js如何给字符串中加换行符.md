title: 在html中js如何给字符串中加换行符
date: '2019-06-03 12:01:39'
updated: '2019-06-03 12:01:39'
tags: [Html, 前端]
permalink: /articles/2019/06/03/1573740598428.html
---
var str = '如果有一天休息休息下cvcvx,'+"\n"+ ' 那么～～～';

这种写法在html中是会被识别为"如果有一天休息休息下`cvcvx,\n 那么～～～"

那么如何保证其这么写会被识别，只需要在该div的样式中加入 `white-space":"pre"` 这个样式