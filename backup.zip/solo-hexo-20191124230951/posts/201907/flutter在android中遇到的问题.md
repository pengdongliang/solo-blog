title: flutter在android中遇到的问题
date: '2019-07-20 14:24:04'
updated: '2019-07-20 14:24:04'
tags: [flutter, 前端]
permalink: /articles/2019/07/20/1573740595996.html
---
## **编译报错: `The number of method references in a .dex file cannot exceed 64K.` (.dex文件中的方法引用数不能超过64k)**

**解决方案: **: 
> 
在`android/app/build.gradle`中的 `dependencies` 下添加 
`implementation 'com.android.support:multidex:1.0.3'`
> 
在`android/app/build.gradle`中的 `defaultConfig` 下添加 
`multiDexEnabled true`

****

## **编译报错, 提示如下:**
```
* What went wrong:
A problem occurred configuring project ':fluwx'.
> Failed to install the following Android SDK packages as some licences have not been accepted.
     platforms;android-27 Android SDK Platform 27
  To build this project, accept the SDK license agreements and install the missing components using the Android Studio SDK Manager.
  Alternatively, to transfer the license agreements from one workstation to another, see http://d.android.com/r/studio-ui/export-licenses.html

  Using Android SDK: E:\AndroidSDK
```

**解决方案: **
> 
可以看出是因为缺少 `[Android SDK Platform 27]`
> 
这时执行 `android list sdk --all` 寻找匹配的序号 
执行 `android update sdk -u -a -t 53` 询问时输入 `"y"` 并耐心等待

****