title: umi或react在vscode上使用TypeScript语法报错问题
date: '2019-09-06 11:50:00'
updated: '2019-09-06 11:50:00'
tags: [React, Umi, 前端]
permalink: /articles/2019/09/06/1573740603532.html
---
### 在`tsconfig.json`里写入下面内容:
```
{
    "compilerOptions": {
        "outDir": "build/dist",
        "module": "esnext",
        "target": "esnext",
        "lib": [
            "esnext",
            "dom"
        ],
        "sourceMap": true,
        "baseUrl": ".",
        "jsx": "react",
        "allowSyntheticDefaultImports": true,
        "moduleResolution": "node",
        "forceConsistentCasingInFileNames": true,
        "noImplicitReturns": true,
        "suppressImplicitAnyIndexErrors": true,
        "noUnusedLocals": true,
        "allowJs": true,
        "experimentalDecorators": true,
        "strict": true,
        "paths": {
            "@/*": [
                "./src/*"
            ]
        }
    },
    "exclude": [
        "node_modules",
        "build",
        "scripts",
        "acceptance-tests",
        "webpack",
        "jest",
        "src/setupTests.ts",
        "tslint:latest",
        "tslint-config-prettier"
    ]
}
```