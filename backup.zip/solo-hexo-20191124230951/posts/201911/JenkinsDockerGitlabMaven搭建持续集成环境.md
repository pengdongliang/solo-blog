title: Jenkins+Docker+Gitlab+Maven搭建持续集成环境
date: '2019-11-10 15:36:32'
updated: '2019-11-10 15:36:32'
tags: [Linux]
permalink: /articles/2019/11/10/1573740599667.html
---
> 参考: https://www.jianshu.com/p/ee4a2a9e7e30

## **搭建gitlab**

### docker拉取gitlab
```
docker pull gitlab/gitlab-ce
```

### 启动gitlab
```
# 注: 
# -v 和 --volume一样, 后面参数[主机目录绝对路径:容器目录]
# --detach 和 -d一样, 后台运行（守护进程）
# --publish 和 -p一样, 主机端口:容器端口
# --restart always, 当 Docker 重启时，容器自动启动
# --name, 容器名称
# –-hostname 和 -h一样, 标志仅更改容器内的主机名.如果您的应用程序需要主机名的特定值,则可能需要这样做.它不会在docker之外更改DNS,也不会更改网络隔离,因此不允许其他人连接到具有该名称的容器.

docker run --detach \
--hostname gitlab.p0d0.com \
--publish 10443:443 --publish 10080:80 --publish 10022:22 \
--name gitlab \
--restart always \
--volume /usr/local/gitlab/config:/etc/gitlab \
--volume /usr/local/gitlab/logs:/var/log/gitlab \
--volume /usr/local/gitlab/data:/var/opt/gitlab \
gitlab/gitlab-ce:latest

```

### **启动gitlab容器后打开浏览器输入地址http://gitlab.p0d0.com:10080 发现访问不了**
- 添加10080端口

    ```
    iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 10080 -j ACCEPT
    iptables-save > /etc/iptables.up.rules  #保存iptables规则
    ```

- 配置Nginx反向代理
    ```
    sudo vi /usr/local/nginx/conf/vhost/gitlab.p0d0.com.conf
    ```
    ```
    server {
      listen 80;
      server_name gitlab.p0d0.com;
      access_log off;
      index index.html index.htm index.jsp;
    
      #error_page 404 /404.html;
      #error_page 502 /502.html;
    
      location ~ .*\.(gif|jpg|jpeg|png|bmp|swf|flv|mp4|ico)$ {
        proxy_pass http://127.0.0.1:10080;
        expires 30d;
        access_log off;
      }
      location ~ .*\.(js|css)?$ {
        proxy_pass http://127.0.0.1:10080;
        expires 7d;
        access_log off;
      }
      location ~ /(\.user\.ini|\.ht|\.git|\.svn|\.project|LICENSE|README\.md) {
        deny all;
      }
      location / {
        proxy_pass http://127.0.0.1:10080/;
        include proxy.conf;
      }
    }
    ```
### 在/etc/hosts里添加
```
127.0.0.1 gitlab.p0d0.com
$ source /etc/hosts
```

### **默认第一次进入要设置新密码, 用户名是 `root`**

****


## **搭建jenkins**

### 拉取jenkins镜像
```
docker pull jenkinsci/jenkins
```

### 启动jenkins
```
# 10000端口是master和slave通信端口
# -u root , 以root用户来启动容器
# --link , 连接gitlab

docker run \
-d \
-p 18080:8080 \
-p 10000:50000 \
--name jenkins \
--link gitlab:gitlab.p0d0.com \
-u root \
-v /usr/local/jenkins:/var/jenkins_home \
jenkinsci/jenkins:latest
```

### **启动访问不了, 同上gitlab配置**