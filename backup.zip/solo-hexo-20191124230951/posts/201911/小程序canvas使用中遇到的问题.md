title: 小程序canvas使用中遇到的问题
date: '2019-11-07 13:12:46'
updated: '2019-11-07 13:12:46'
tags: [前端, 小程序]
permalink: /articles/2019/11/07/1573740586473.html
---
## **canvas画图ctx.drawImage()图片在真机上不显示**

- 网络图片记得使用`wx.drawImage`或者`wx.downloadFile`下载下来使用临时路径
- **如果本地图片和网络图片下载下来了还是不能显示, 查看`<canvas/>`的宽高必须是有值**