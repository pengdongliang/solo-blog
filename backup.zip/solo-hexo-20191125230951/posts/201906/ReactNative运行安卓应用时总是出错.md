title: React-Native 运行安卓应用时总是出错
date: '2019-06-03 11:56:22'
updated: '2019-06-03 11:56:22'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740581197.html
---
```

> You have not accepted the license agreements of the following SDK components:
[Android SDK Platform 23].
```
### 可以看出是因为缺少 `[Android SDK Platform 23]`
这时执行`android list sdk --all` 寻找匹配的序号
执行 `android update sdk -u -a -t 53` 询问时输入 "y" 并耐心等待

> [参考](https://segmentfault.com/a/1190000008395219)

### 运行时报错
1. 可以试下升级下版本
 react-native upgrade
2. react-native link重复添加了, 手动删除多余的即可
 > 项目根路径 > android > app > src > main > java > com > "你的项目名" > MainApplication.java > `protected List getPackages() {// 里面的重复删除}`
3. 清除缓存
 `react-native start --reset-cache`



### 项目之前运行好好的, 突然不能正常编译了, 报错如下:
```
error: bundling failed: Error: Unable to resolve module `./babel/runtime/helpers/classCallCheck` from `D:\react-native\m
apDemo\src\router.tsx`: The module `./babel/runtime/helpers/classCallCheck` could not be found from `D:\react-native\map
Demo\src\router.tsx`. Indeed, none of these files exist:
```
解决方法: 

- 删除node_modules文件夹

- package.json： "react": "16.8.3", "react-native": "0.59.2", "react-redux": "6.0.1"

- npm安装

node_modules\react-native\scripts\launchPackager.bat和它一样生活node "%~dp0..\cli.js" start

- 改变 @react-native-community\cli\build\commands\runAndroid\runAndroid.js ：

- const procConfig = { cwd: process.cwd() }

- npm cache clean --force

- npm start --clear-cache

- react-native start --reset-cache
以及我之前完成的这一步

- 删除 C:\Users\YOURUSERNAME\AppData\Local\Temp\metro-cache