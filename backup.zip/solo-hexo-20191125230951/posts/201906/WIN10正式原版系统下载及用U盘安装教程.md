title: WIN10正式原版系统下载及用U盘安装教程
date: '2019-06-03 11:46:23'
updated: '2019-06-03 11:46:23'
tags: [Windows]
permalink: /articles/2019/06/03/1573740594818.html
---
> https://jingyan.baidu.com/article/77b8dc7fae87ca6175eab641.html