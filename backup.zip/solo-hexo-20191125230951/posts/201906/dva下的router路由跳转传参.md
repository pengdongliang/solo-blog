title: dva下的router(路由跳转传参)
date: '2019-06-03 11:57:52'
updated: '2019-06-03 11:57:52'
tags: [Dva, React, 前端]
permalink: /articles/2019/06/03/1573740607954.html
---
### 1. 切换 history 为 browserHistory(适用于routes里的页面里使用)
    import { browserHistory } from 'dva/router';
    const app = dva({
      history: browserHistory,
    });

#### 传参方式1
    browserHistory.push(pathname: '/routerName/123')
取参

    this.props.params.value
#### 传参方式2
    browserHistory.push({pathname: "/page", state: {key: value}})
取参

    this.props.location.state.key
### 2. routerRedux
    import { routerRedux } from 'dva/router';
    // 在 Effects 里
    yield put(routerRedux.push('/logout'));
    
    // 不在 Effects 里
    dispatch(routerRedux.push('/logout'));
    
    // 传参
    routerRedux.push({
      pathname: '/logout',
      query: {
        page: 2,
      },
    });
    // 取参
    this.props.location.query.page
### 3. Link
    import { Link } from 'dva/router';
    
    // 传参
    
    
    
## 路由传参key(state, query, search, param)
    //使用search
    import qs from 'query-string';
    routerRedux.push({
        pathname: '/',
        search: qs.stringify({
          abc: '123',
        })
    })