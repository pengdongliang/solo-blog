title: export注意点
date: '2019-06-03 11:58:16'
updated: '2019-06-03 11:58:16'
tags: [Dva, React, 前端]
permalink: /articles/2019/06/03/1573740591080.html
---
## react里一个组件如果是被路由直接require导入进路由配置里的话, 当前组件里不能写`export const xxx = xxx;`, 会导致路由错乱跳到首页. (个人理解: 可能是导入的时候认为一个组件里的export default和export xxx的问题)
 可以写`export default xxx`
 
router.js: 
    
    {
        path: 'firmwareUpdate/:record',//OTA固件升级详情
        getComponent(nextState, cb) {
            pathChange = false;
            require.ensure([], require => {
                registerModel(app, require('./models/firmwareUpdate'));
                if (!pathChange) {
                    cb(null, require('./routes/firmwareUpdate/detail'));//**注意**这样引入的组件里面不能写export xxx
                }
            }, 'firmwareUpdate');
        },
    },
    
xxx.js
    
    class Xxx extends Component{
        
    }
    export default connect(({a})=> ({a}))(Xxx);//这样正常