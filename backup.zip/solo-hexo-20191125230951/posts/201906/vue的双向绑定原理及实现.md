title: vue的双向绑定原理及实现
date: '2019-06-04 16:20:54'
updated: '2019-06-04 16:20:54'
tags: [Vue, 前端]
permalink: /articles/2019/06/04/1573740600061.html
---
> 
参考: https://www.cnblogs.com/libin-1/p/6893712.html
参考: [剖析Vue原理&实现双向绑定MVVM](https://segmentfault.com/a/1190000006599500)