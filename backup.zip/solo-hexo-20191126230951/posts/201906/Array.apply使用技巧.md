title: Array.apply使用技巧
date: '2019-06-03 12:00:29'
updated: '2019-06-03 12:00:29'
tags: [JavaScript, 前端]
permalink: /articles/2019/06/03/1573740602637.html
---
- `Array.apply(null, {length: 20})`
- 参考: https://segmentfault.com/a/1190000011435501
- `map函数并不会遍历数组中没有初始化或者被delete的元素（有相同限制还有forEach, reduce方法）`