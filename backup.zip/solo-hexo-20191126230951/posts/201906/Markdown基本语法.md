title: Markdown基本语法
date: '2019-06-03 11:43:33'
updated: '2019-06-03 11:43:33'
tags: [Others]
permalink: /articles/2019/06/03/1573740603317.html
---
> [基础](https://blog.csdn.net/chenguangxing3/article/details/25346493)

> $ cd ./mark 

<span color="red" data-mce-style="color: red;" style="color: red;">红色</span>