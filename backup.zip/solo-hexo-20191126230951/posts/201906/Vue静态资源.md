title: Vue静态资源
date: '2019-06-04 16:07:13'
updated: '2019-06-04 16:07:13'
tags: [Vue, 前端]
permalink: /articles/2019/06/04/1573740584333.html
---
- *vue-cli2: *
> 图片等静态资源放入<font color=red>根目录下的static</font>下
  引入: `src="static/logo.png"`

- *vue-cli3: *
> 图片等静态资源放入<font color=red>根目录下的public</font>下
  引入: `src="/logo.png"`