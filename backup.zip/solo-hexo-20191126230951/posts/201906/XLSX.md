title: XLSX
date: '2019-06-18 11:49:07'
updated: '2019-06-18 11:49:07'
tags: [前端, 插件]
permalink: /articles/2019/06/18/1573740594988.html
---
## 生成xlsx文件

#### createXLSX.js
```
/**
 * create time: 18/6/2019
 * author: Peng
 */


import XLSX from "xlsx"
import { message } from "antd"


/**
 * 
 * @param {Array} msgArr
 * 例子: 
 *  表头
 *  const headers = ['id', 'name', 'age', 'country'];
 *  表格数据
 *  const data = [
 *      {
 *          id: '1',
 *          name: 'test1',
 *          age: '30',
 *          country: 'China',
 *      },
 *  ];
 * @param {String} outputName
 * default = "output"
 */
export const createXLSX = ({ msgArr = [], outputName = "output" }) => {
    console.log(msgArr)
    if (!msgArr.length) {
        message.warning("需要下载的数据为空")
        return
    }
    const headers = Object.keys(msgArr[0])
    const newHeaders = headers
        .map((v, i) => Object.assign({}, { v: v, position: String.fromCharCode(65 + i) + 1 }))
        .reduce((prev, next) => Object.assign({}, prev, { [next.position]: { v: next.v } }), {});

    const newData = msgArr
        .map((v, i) => headers.map((k, j) => Object.assign({}, { v: v[k], position: String.fromCharCode(65 + j) + (i + 2) })))
        .reduce((prev, next) => prev.concat(next))
        .reduce((prev, next) => Object.assign({}, prev, { [next.position]: { v: next.v } }), {});
    const output = Object.assign({}, newHeaders, newData);
    // 获取所有单元格的位置
    const outputPos = Object.keys(output);
    // 计算出范围
    const ref = outputPos[0] + ':' + outputPos[outputPos.length - 1];

    // 构建 workbook 对象
    const workbook = {
        SheetNames: ['mySheet'],
        Sheets: {
            'mySheet': Object.assign({}, output, { '!ref': ref })
        }
    };

    // 导出 Excel
    XLSX.writeFile(workbook, outputName + '.xlsx')
}
```

#### 使用
```
import { createXLSX } from "createXLSX.js"

createXLSX(xlsxArr)
```