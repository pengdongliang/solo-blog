title: axios上传文件
date: '2019-06-04 16:43:01'
updated: '2019-06-04 16:43:01'
tags: [React, 前端]
permalink: /articles/2019/06/04/1573740580366.html
---
### axios Content-Type: multipart/form-data(上传文件)

        let formData = new FormData();
        formData.append('appkey', 'njssdjtkj');
        formData.append('sign', sign);
        formData.append('sign_method', "MD5");
        formData.append('mobile', "15951971791");
        formData.append('engine_no', "070939");
        formData.append('plate_type', "02");
        formData.append('plate_no', "苏EXW365");


        axios({
            method: 'post',
            url: '/api/search.do',
            data:formData,
            //:{appkey: "njssdjtkj",sign:sign,sign_method:"MD5",timestamp:time,mobile:"15951971791",engine_no:"070939",plate_type:"02",plate_no:"苏EXW365"},
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        })
        .then(function (res) {
            console.log(res)
        })