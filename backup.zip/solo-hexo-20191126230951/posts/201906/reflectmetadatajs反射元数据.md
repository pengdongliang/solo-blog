title: reflect-metadata js反射元数据
date: '2019-06-03 11:59:42'
updated: '2019-06-03 11:59:42'
tags: [Npm, 前端]
permalink: /articles/2019/06/03/1573740604877.html
---
## **参考**
> [JavaScript Reflect Metadata 详解](https://www.jianshu.com/p/653bce04db0b)

## **安装**
> npm i reflect-metadata -S

## **使用**
tsconfig.json:
```
{
    "compilerOptions": {
        "target": "ES5",
        "experimentalDecorators": true,
        "emitDecoratorMetadata": true
    }
}
```
使用的地方:
```
import "reflect-metadata";

class Line {
    private _p0: Point;
    private _p1: Point;

    @validate
    @Reflect.metadata("design:type", Point)
    set p0(value: Point) { this._p0 = value; }
    get p0() { return this._p0; }

    @validate
    @Reflect.metadata("design:type", Point)
    set p1(value: Point) { this._p1 = value; }
    get p1() { return this._p1; }
}
```

## **用途**
> 
其实所有的用途都是一个目的，给对象添加额外的信息，但是不影响对象的结构。这一点很重要，当你给对象添加了一个原信息的时候，对象是不会有任何的变化的，不会多 property，也不会有的 property 被修改了。
但是可以衍生出很多其他的用途。
> 
- Anuglar 中对特殊字段进行修饰 (Input)，从而提升代码的可读性。
- 可以让装饰器拥有真正装饰对象而不改变对象的能力。让对象拥有更多语义上的功能

## **API**
```
//定义对象或属性的元数据
Reflect.defineMetadata（metadataKey，metadataValue，target）;
Reflect.defineMetadata（metadataKey，metadataValue，target，propertyKey）;
 
//检查对象或属性的原型链上是否存在元数据键
let result = Reflect.hasMetadata（metadataKey，target）;
let result = Reflect.hasMetadata（metadataKey，target，propertyKey）;
 
//检查是否存在对象或属性的自己的元数据键
let result = Reflect.hasOwnMetadata（metadataKey，target）;
let result = Reflect.hasOwnMetadata（metadataKey，target，propertyKey）;
 
//获取对象或属性的原型链上的元数据键的元数据值
let result = Reflect.getMetadata（metadataKey，target）;
let result = Reflect.getMetadata（metadataKey，target，propertyKey）;
 
//获取对象或属性的自己的元数据键的元数据值
let result = Reflect.getOwnMetadata（metadataKey，target）;
let result = Reflect.getOwnMetadata（metadataKey，target，propertyKey）;
 
//获取对象或属性的原型链上的所有元数据键
let result = Reflect.getMetadataKeys（target）;
let result = Reflect.getMetadataKeys（target，propertyKey）;
 
//获取对象或属性的所有自己的元数据键
let result = Reflect.getOwnMetadataKeys（target）;
let result = Reflect.getOwnMetadataKeys（target，propertyKey）;
 
//从对象或属性中删除元数据
let result = Reflect.deleteMetadata（metadataKey，target）;
let result = Reflect.deleteMetadata（metadataKey，target，propertyKey）;
 
//通过装饰器将元数据应用于构造函数
@Reflect.metadata（metadataKey，metadataValue）
C级{
  //通过装饰器将元数据应用于方法（属性）
  @Reflect.metadata（metadataKey，metadataValue）
  方法（） {
  }
}
```