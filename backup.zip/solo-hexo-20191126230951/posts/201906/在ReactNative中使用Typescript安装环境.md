title: 在ReactNative中使用Typescript(安装环境)
date: '2019-06-03 11:55:15'
updated: '2019-06-03 11:55:15'
tags: [React-Native, 前端]
permalink: /articles/2019/06/03/1573740593198.html
---
# **注意: 可以直接在创建项目的时候使用命令**
> `react-native init MyAwesomeProject --template typescript`

## **[优雅地使用TypeScript开发React Native应用](https://juejin.im/post/5cd978ef6fb9a031fe3be6bd)**

****

## 参考:
> https://blog.csdn.net/s2096828/article/details/83744677

## 首先安装react-native-typescript-transformer 和 typescript 模块
### npm
> npm i --dev react-native-typescript-transformer typescript
### yarn
> yarn add --dev react-native-typescript-transformer typescript
## 然后在项目的根目录下创建一个文件 `rn-cli.config.js`
```
module.exports = {  
      getTransformModulePath() {
        return require.resolve('react-native-typescript-transformer')
      },
      getSourceExts() {
        return ['ts', 'tsx'];
      }
}
```
## 在项目根目录下创建一个文件`tsconfig.json`
```
{
      "compilerOptions": {
        "target": "es2015",
        "module": "es2015",
        "jsx": "react-native",
        "moduleResolution": "node",
        "allowSyntheticDefaultImports": true
      }
}
```
## 然后就可以放心在项目里写TypeScript代码了，例如项目中ts目录下有test.ts文件，我们在import这个文件时，就像import一个js文件就可以了
```
import './ts/test'
```