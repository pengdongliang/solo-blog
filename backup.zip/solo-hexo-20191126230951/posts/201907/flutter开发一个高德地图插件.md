title: flutter开发一个高德地图插件
date: '2019-07-31 11:21:46'
updated: '2019-07-31 11:21:46'
tags: [flutter, 前端]
permalink: /articles/2019/07/31/1573740587083.html
---
> 参考: https://juejin.im/post/5bdfa3d151882534d44e1eca

## **创建plugin package**
> flutter create --org com.p0d0 --template=plugin flutter_amaps

### 默认情况下，创建的plugin项目是使用objective-c（ios）和java（Android）编写，如果需要增加对swift和kotlin的支持，可以在命令中添加 -i 和 -a。

> flutter create --org com.kinsomy --template=plugin flutter_amaps -i swift -a kotlin hello

### 也可以用Android studio直接创建：选择新建FLutter project，然后选择plugin project即可。swift和kotlin的支持在创建界面上勾选即可。

## **项目结构**

- **lib/amap_location_plugin.dart**
这是plugin package中dart api的代码部分，是供使用者在他们自己的flutter项目中调用的接口代码。

- **AmapLocationPlugin.java**
这是plugin package中Android部分的具体实现，要和上面的dart api配合进行开发。

- **ios/**
这里是plugin package ios部分的具体实现，和上面Android实现类似，编写ios平台特定代码。

- **example/**
这是用来说明使用plugin package的示例代码，里面源码依赖了写好的plugin。

- **vscode启动: 在example目录里按F5启动调试**


## 配置环境

1. 方式一: 可以选择下载 [**高德地图SDK**](https://lbs.amap.com/api) 这种方式, 参考[**高德官网配置**](https://lbs.amap.com/api/android-sdk/guide/create-project/android-studio-create-project) , 申请appkey

2. 方式二: **集成远程依赖**
  在根目录下的 `android` -> `build.gradle` 里添加 
    ```
    android {
        ...
        dependencies {
            implementation 'com.amap.api:3dmap:latest.integration' // 3D地图
            implementation 'com.amap.api:search:latest.integration' // 搜索
            implementation 'com.amap.api:location:latest.integration' // 定位 	
            implementation 'com.amap.api:navi-3dmap:latest.integration' // 导航(包括地图, 不要和3D地图同时引入)
        }
    }
    ```

3. **配置app key 和 声明service**, 如下:
    ```
    <manifest xmlns:android="http://schemas.android.com/apk/res/android" package="com.p0d0.flutter_amaps">
    
        <!-- 获取运营商信息，用于支持提供运营商信息相关的接口 -->
        <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    
        <!-- 用于访问wifi网络信息，wifi信息会用于进行网络定位 -->
        <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
        
        <!-- 这个权限用于获取wifi的获取权限，wifi信息会用来进行网络定位 -->
        <uses-permission android:name="android.permission.CHANGE_WIFI_STATE"/>
        <uses-permission android:name="android.permission.CHANGE_CONFIGURATION"/>
    
        <!-- 请求网络 -->
        <uses-permission android:name="android.permission.INTERNET"/>
    
        <!-- 不是SDK需要的权限，是示例中的后台唤醒定位需要的权限 -->
        <uses-permission android:name="android.permission.WAKE_LOCK"/>
    
        <!-- 需要运行时注册的权限 -->
        <!-- 用于进行网络定位 -->
        <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    
        <!-- 用于访问GPS定位 -->
        <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    
        <!-- 用于提高GPS定位速度 -->
        <uses-permission android:name="android.permission.ACCESS_LOCATION_EXTRA_COMMANDS"/>
    
        <!-- 写入扩展存储，向扩展卡写入数据，用于写入缓存定位数据 -->
        <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
    
        <!-- 读取缓存数据 -->
        <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    
        <!-- 用于读取手机当前的状态 -->
        <uses-permission android:name="android.permission.READ_PHONE_STATE"/>
    
        <!-- 更改设置 -->
        <uses-permission android:name="android.permission.WRITE_SETTINGS"/>
    
    
        <application>
    
            <meta-data android:name="com.amap.api.v2.apikey" android:value="${LOCATION_APP_KEY}" />
    
            <!-- 定位需要的服务 -->
            <service android:name="com.amap.api.location.APSService"></service>
    
        </application>
    
    </manifest>
    ```

4. **这个LOCATION_APP_KEY**，使用者使用插件的时候在自己flutter项目的android工程下的app/build.gradle文件里填写自己申请的高德key即可。如下:
    ```
    android {
        compileSdkVersion 27
    
        lintOptions {
           ...
        }
    
        defaultConfig {
            ...
            manifestPlaceholders = [
                    LOCATION_APP_KEY : "630cedfa3449ed11eb47bd52cb91ef7b", /// 高德地图key
            ]
        }
    }
    ```

5. 到目前为止，一个基于高德sdk的定位插件工程就算配置好了