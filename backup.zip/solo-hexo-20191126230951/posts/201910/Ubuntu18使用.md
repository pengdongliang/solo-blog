title: Ubuntu18使用
date: '2019-10-28 21:07:59'
updated: '2019-10-28 21:07:59'
tags: [Linux]
permalink: /articles/2019/10/28/1573740601565.html
---
## **添加8080端口进防火墙**
```
iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 8080 -j ACCEPT
iptables-save > /etc/iptables.up.rules  #保存iptables规则
```

## **更改redis访问IP方式**
```
vi /usr/local/redis/etc/redis.conf
bind 127.0.0.1  #改成bind 0.0.0.0，保存
service redis-server restart   #重启生效
```


## **msyql添加一个用户名为db_user，密码为db_pass，授权为本机localhost对db_name数据库所有权限，命令如下**
```
如：添加一个用户名为db_user，密码为db_pass，授权为% （%表示所有外围IP能连接）对db_name数据库所有权限，命令如下
# mysql -uroot -p
MySQL [(none)]> grant all privileges on db_name.* to db_user@'%' identified by 'db_pass'; #授权语句，特别注意有分号
MySQL [(none)]> flush privileges;
MySQL [(none)]> exit; #退出数据库控制台，特别注意有分号
```

## 

## **java变量或者其它变量切换角色后没用了**
### 在~/.bashrc 末尾添加 `source /etc/profile`
```
# 更新
source /etc/profile
```

## **ubuntu路径太长**
```
$ vi ~/.bashrc
:set nu
在62行
if [ "$color_prompt " = yes ]; then
    PS1 ='${debian_chroot:+($debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\W \[\033[00m\]\$ '
else
    PS1='${debian_chroot:+($debian_chroot)}\u@\h:\w\$ ' # 这里的小写w修改为大写的W

$ source ~/.bashrc
```