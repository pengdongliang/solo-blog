title: http抓包工具
date: '2019-11-13 09:39:52'
updated: '2019-11-13 09:39:52'
tags: [开发小工具]
permalink: /articles/2019/11/13/1573740585104.html
---
- ### **Httpwatch**

- ### **Firebug**

- ### **Charles**

- ### **Wireshark**

- ### **Fiddler**(可拦截请求并修改返回数据, 是 web、移动应用的开发调试利器)
> 
    1. 功能特点
        - 同 Httpwatch、Firebug 这些抓包工具一样，Fiddler 够记录客户端和服务器之间的所有 HTTP 请求，可以针对特定的 HTTP 请求，分析请求数据、设置断点等。
        - 但 Fiddler 更为强大的是，它还可以修改请求的数据，甚至可以实现请求自动重定向，从而修改服务器返回的数据。
        - Fiddler 使用也十分方便。在打开 Fiddler 的时候，它就自动设置好了浏览器的代理，通过改写 HTTP 代理，让数据从它那通过，来监控并且截取到数据。当关闭 Fiddler 的时候，它又自动帮你把代理还原。
    2. 下载安装
直接去 Fiddler 的官网下载即可。地址：http://www.telerik.com/fiddler